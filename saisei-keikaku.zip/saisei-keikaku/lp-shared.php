<?php
/**
 * 再生計画 サイト共通パーツ
 *
 * 各ページテンプレートの先頭で require_once します。
 * デザイン言語は Design/Landing Page を参考にした編集的（エディトリアル）アプローチ:
 *   - 見出しに明朝体（Shippori Mincho B1）
 *   - 数字／タグに Plus Jakarta Sans
 *   - oklch ベースのエコトーンパレット
 *   - シャープな角丸（4px / 8px）と細い罫線
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 【設定】サイトに合わせて書き換えてください。
 */
function lp_cfg() {
	static $cfg = null;
	if ( null !== $cfg ) {
		return $cfg;
	}
	$cfg = array(
		'company'    => '有限会社 再生計画',
		'company_en' => 'Saisei Keikaku Co., Ltd.',
		'ceo'        => '松島 弘和',
		'ceo_en'     => 'Hirokazu Matsushima',
		'capital'    => '300万円',
		'capital_en' => 'JPY 3,000,000',
		'tel'        => '0532-47-4999',
		'tel_link'   => '+81532474999',
		'fax'        => '0532-47-6524',
		'mail'       => 'hm@saiseikeikaku.com',
		'address'    => '〒441-8122 愛知県豊橋市天伯町字天伯84番地',
		'address_en' => '84 Aza-Tenpaku, Tenpaku-cho, Toyohashi-shi, Aichi 441-8122, Japan',
		'img'        => get_stylesheet_directory_uri() . '/images/lp',
		// グローバルナビ: キー => array( 'ja' => 日本語, 'en' => English, 'path' => スラッグ )
		'nav'        => array(
			'home'    => array( 'ja' => 'ホーム',              'en' => 'Home',           'path' => '/' ),
			'company' => array( 'ja' => '会社案内',            'en' => 'About',          'path' => '/company-detail/' ),
			'green'   => array( 'ja' => '植物活性液',          'en' => 'Pure Green',     'path' => '/pure-green/' ),
			'brown'   => array( 'ja' => '植物性有機肥料',      'en' => 'Organic Brown',  'path' => '/organic-brown/' ),
			'sdgs'    => array( 'ja' => 'SDGs',               'en' => 'SDGs',           'path' => '/sdgs/' ),
			'contact' => array( 'ja' => 'お問い合わせ',        'en' => 'Contact',        'path' => '/contact-us/' ),
			'privacy' => array( 'ja' => 'プライバシーポリシー', 'en' => 'Privacy Policy', 'path' => '/privacypolicy/' ),
		),
	);
	return $cfg;
}

/* ============================================================
 * 多言語（日本語 / English）
 *   - Cookie `lp_lang` で言語を保持（'en' なら英語、それ以外は日本語）
 *   - lp_t( $ja, $en ) で文字列を取得
 *   - lp_header() の切替ボタンが Cookie を更新→リロード
 * ============================================================ */

/** 現在の表示言語を返す（'ja' または 'en'）。 */
function lp_lang() {
	static $lang = null;
	if ( null !== $lang ) {
		return $lang;
	}
	$lang = ( isset( $_COOKIE['lp_lang'] ) && 'en' === $_COOKIE['lp_lang'] ) ? 'en' : 'ja';
	return $lang;
}

/** 言語別の文字列を返す。 */
function lp_t( $ja, $en ) {
	return ( 'en' === lp_lang() ) ? $en : $ja;
}

/** 会社情報を言語別に取得（'_en' サフィックス付きフィールドがあれば優先）。 */
function lp_cf( $key ) {
	$cfg = lp_cfg();
	if ( 'en' === lp_lang() && isset( $cfg[ $key . '_en' ] ) ) {
		return $cfg[ $key . '_en' ];
	}
	return isset( $cfg[ $key ] ) ? $cfg[ $key ] : '';
}

/** 会社名（言語別） */
function lp_company_name() {
	return lp_cf( 'company' );
}

/**
 * 固定ページのURLを返す。
 * パーマリンク設定（基本／投稿名など）に関わらず正しいURLを生成します。
 *
 * @param string $path スラッグまたはパス（'/' または空でホーム）。
 * @return string
 */
function lp_page_url( $path ) {
	$slug = trim( (string) $path, '/' );
	if ( '' === $slug ) {
		return home_url( '/' );
	}
	$page = get_page_by_path( $slug );
	if ( $page ) {
		return get_permalink( $page );
	}
	return home_url( '/' . $slug . '/' );
}

/** お問い合わせページのURL */
function lp_contact_url() {
	$cfg = lp_cfg();
	return lp_page_url( $cfg['nav']['contact']['path'] );
}

/**
 * テーマ内アセットの存在確認。
 */
function lp_asset_exists( $rel ) {
	return is_file( get_stylesheet_directory() . '/' . ltrim( $rel, '/' ) );
}

/** テーマ内アセットのURLを返す。 */
function lp_asset_url( $rel ) {
	return get_stylesheet_directory_uri() . '/' . ltrim( $rel, '/' );
}

/**
 * 会社ロゴのURL（存在しなければ空文字）。
 * 大文字小文字いずれのファイル名も許容。
 */
function lp_company_logo_url() {
	foreach ( array( 'images/Logo.png', 'images/logo.png' ) as $rel ) {
		if ( lp_asset_exists( $rel ) ) {
			return lp_asset_url( $rel );
		}
	}
	return '';
}

/**
 * SDGsアセット（バイリンガル）のURLを返す。
 * images/sdgs/{lang}/<filename> → images/sdgs/<filename> の順で探索。
 *
 * @param string $filename ファイル名（例: sdg-03.png）。
 * @return string 見つかったURL、なければ空文字。
 */
function lp_sdgs_asset( $filename ) {
	$candidates = array(
		'images/sdgs/' . lp_lang() . '/' . $filename,
		'images/sdgs/' . $filename,
	);
	foreach ( $candidates as $rel ) {
		if ( lp_asset_exists( $rel ) ) {
			return lp_asset_url( $rel );
		}
	}
	return '';
}

/**
 * <!DOCTYPE> 〜 <body> 開始タグまでを出力（共通CSS含む）。
 */
function lp_head( $title, $desc, $body_class = '' ) {
	$is_en = ( 'en' === lp_lang() );
	$sep   = $is_en ? ' | ' : '｜';
	?>
<!DOCTYPE html>
<html lang="<?php echo $is_en ? 'en' : 'ja'; ?>">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?php echo esc_attr( $desc ); ?>">
<title><?php echo esc_html( $title . $sep . lp_company_name() ); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Shippori+Mincho+B1:wght@500;600;700;800&family=Noto+Sans+JP:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700&display=swap');

/* ===== Design Tokens ===== */
:root{
	/* Palette */
	--bg: oklch(0.975 0.012 110);
	--bg-deep: oklch(0.945 0.018 120);
	--card: #ffffff;
	--line: oklch(0.88 0.014 110);
	--line-strong: oklch(0.78 0.018 120);
	--ink: oklch(0.22 0.022 150);
	--ink-2: oklch(0.36 0.022 150);
	--ink-mute: oklch(0.5 0.018 145);
	--green-900: oklch(0.30 0.06 148);
	--green-800: oklch(0.38 0.08 148);
	--green-700: oklch(0.48 0.10 148);
	--green-500: oklch(0.66 0.12 148);
	--green-200: oklch(0.92 0.04 148);
	--green-100: oklch(0.96 0.025 148);
	--earth: oklch(0.55 0.06 65);
	--accent: oklch(0.62 0.13 75);

	/* Backward-compat aliases（既存テンプレ内の inline style 用） */
	--green-dark: var(--green-900);
	--green: var(--green-700);
	--green-light: var(--green-100);
	--text: var(--ink);
	--muted: var(--ink-mute);
	--bg-soft: var(--bg-deep);

	/* Type */
	--serif: "Shippori Mincho B1","Yu Mincho","游明朝","YuMincho","ヒラギノ明朝 ProN",serif;
	--sans: "Noto Sans JP",-apple-system,BlinkMacSystemFont,"Hiragino Kaku Gothic ProN","Yu Gothic",sans-serif;
	--num: "Plus Jakarta Sans","Noto Sans JP",sans-serif;

	/* Layout */
	--maxw: 1180px;
	--pad-x: clamp(20px,4vw,48px);
	--radius: 4px;
	--radius-lg: 8px;
	--shadow: 0 24px 50px -30px oklch(0.30 0.06 148 / .35);
}

/* ===== Reset / Base ===== */
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.lp-body{
	font-family:var(--sans);color:var(--ink);background:var(--bg);
	line-height:1.85;font-size:16px;
	font-feature-settings:"palt" 1;
	-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
}
.lp-body img{max-width:100%;height:auto;display:block}
a{color:inherit;text-decoration:none}
button{font:inherit;cursor:pointer}

.lp-wrap{max-width:var(--maxw);margin:0 auto;padding-left:var(--pad-x);padding-right:var(--pad-x)}
.lp-section{padding:clamp(72px,9vw,120px) 0}
.lp-section--soft{background:var(--bg-deep)}

/* ===== Headings ===== */
.lp-eyebrow{
	display:inline-block;font-family:var(--num);
	font-size:11px;font-weight:600;letter-spacing:.24em;text-transform:uppercase;
	color:var(--green-700);margin-bottom:14px;
}
.lp-h2{
	font-family:var(--serif);font-weight:700;
	font-size:clamp(28px,3.8vw,46px);line-height:1.3;letter-spacing:.02em;
	color:var(--ink);margin-bottom:18px;text-wrap:balance;
}
.lp-lead{color:var(--ink-2);font-size:15px;line-height:2;max-width:760px;text-wrap:pretty}
.lp-center{text-align:center}
.lp-center .lp-lead{margin-left:auto;margin-right:auto}

/* ===== Buttons ===== */
.lp-btn{
	display:inline-flex;align-items:center;justify-content:center;gap:8px;
	font-family:inherit;font-weight:600;font-size:14px;letter-spacing:.02em;
	padding:12px 22px;border-radius:999px;border:1px solid transparent;
	text-decoration:none;cursor:pointer;white-space:nowrap;
	transition:transform .2s,background .2s,box-shadow .2s,border-color .2s,filter .2s;
}
.lp-btn--primary{background:var(--green-800);color:#fff;border-color:var(--green-800)}
.lp-btn--primary:hover{background:var(--green-900);border-color:var(--green-900);transform:translateY(-1px);box-shadow:0 10px 22px -10px var(--green-800)}
.lp-btn--ghost{background:transparent;color:var(--ink);border-color:var(--line-strong)}
.lp-btn--ghost:hover{background:var(--card);border-color:var(--ink-2)}
.lp-btn--accent{background:var(--accent);color:#fff;border-color:var(--accent)}
.lp-btn--accent:hover{transform:translateY(-1px);box-shadow:0 10px 22px -10px var(--accent);filter:brightness(.97)}
.lp-btn--lg{padding:16px 28px;font-size:15px}

/* ===== Header ===== */
.lp-header{
	position:sticky;top:0;z-index:50;
	background:oklch(0.975 0.012 110 / .88);
	backdrop-filter:saturate(160%) blur(10px);
	-webkit-backdrop-filter:saturate(160%) blur(10px);
	border-bottom:1px solid var(--line);
}
.lp-nav-toggle{display:none}
.lp-bar__inner{display:flex;align-items:center;justify-content:space-between;gap:14px;height:72px}
.lp-logo{display:flex;align-items:center;gap:12px;color:var(--ink)}
.lp-logo img{display:block;height:48px;width:auto}
.lp-logo__text{
	font-family:var(--serif);font-weight:700;font-size:15px;color:var(--ink);
	letter-spacing:.02em;line-height:1.3;
}
.lp-logo__text small{
	display:block;font-family:var(--num);font-weight:500;font-size:10px;
	letter-spacing:.16em;color:var(--ink-mute);margin-top:4px;line-height:1;
}
.lp-bar__right{display:flex;align-items:center;gap:14px}
.lp-bar__tel{display:flex;flex-direction:column;line-height:1.1;text-align:right;color:var(--green-900)}
.lp-bar__tel small{font-size:10px;color:var(--ink-mute);letter-spacing:.08em;font-weight:600}
.lp-bar__tel b{font-family:var(--num);font-weight:700;font-size:18px;color:var(--green-900);letter-spacing:.02em}
.lp-bar__cta{padding:11px 20px;font-size:13.5px}

/* 言語切替（JA/EN） */
.lp-lang{display:inline-flex;border:1px solid var(--line);border-radius:999px;overflow:hidden;background:var(--card)}
.lp-lang__btn{
	background:transparent;color:var(--ink-mute);border:0;cursor:pointer;font-family:var(--num);
	font-size:11px;font-weight:600;padding:6px 12px;letter-spacing:.06em;transition:background .15s ease,color .15s ease;
}
.lp-lang__btn.is-active{background:var(--ink);color:var(--card)}
.lp-lang__btn:not(.is-active):hover{background:var(--bg-deep);color:var(--ink)}

.lp-gnav{border-top:1px solid var(--line);background:var(--card)}
.lp-gnav__inner{display:flex;justify-content:center;gap:0;flex-wrap:wrap}
.lp-gnav__link{
	position:relative;padding:14px 22px;
	color:var(--ink-2);font-size:13.5px;font-weight:500;letter-spacing:.02em;
	transition:color .15s;
}
.lp-gnav__link:hover{color:var(--green-800)}
.lp-gnav__link.is-current{color:var(--green-800)}
.lp-gnav__link:hover::after,
.lp-gnav__link.is-current::after{
	content:"";position:absolute;left:22px;right:22px;bottom:6px;height:1px;background:var(--green-700);
}

.lp-burger{display:none;flex-direction:column;justify-content:center;gap:5px;width:44px;height:44px;cursor:pointer}
.lp-burger span{display:block;height:2px;width:22px;background:var(--green-800);border-radius:2px;transition:transform .2s,opacity .2s}

/* ===== Page Head（下層） ===== */
.lp-pagehead{
	background:var(--bg-deep);padding:clamp(56px,8vw,96px) 0;text-align:center;
	border-bottom:1px solid var(--line);
}
.lp-pagehead__en{
	display:block;font-family:var(--num);font-size:11px;font-weight:600;
	letter-spacing:.24em;text-transform:uppercase;color:var(--green-700);margin-bottom:14px;
}
.lp-pagehead h1{
	font-family:var(--serif);font-weight:700;
	font-size:clamp(28px,4vw,42px);letter-spacing:.04em;color:var(--ink);line-height:1.3;text-wrap:balance;
}
.lp-breadcrumb{background:var(--card);border-bottom:1px solid var(--line);font-size:12px;color:var(--ink-mute)}
.lp-breadcrumb .lp-wrap{padding-top:14px;padding-bottom:14px}
.lp-breadcrumb a{color:var(--green-700)}
.lp-breadcrumb a:hover{text-decoration:underline}
.lp-breadcrumb span{margin:0 9px;color:var(--line-strong)}

/* ===== Prose（プライバシーポリシー等の本文） ===== */
.lp-prose{max-width:780px;margin:0 auto}
.lp-prose h2{
	font-family:var(--serif);font-weight:700;font-size:22px;line-height:1.5;letter-spacing:.02em;
	color:var(--ink);margin:40px 0 16px;padding-left:14px;border-left:3px solid var(--green-700);
}
.lp-prose h2:first-child{margin-top:0}
.lp-prose h3{font-family:var(--serif);font-weight:700;font-size:17px;color:var(--ink);margin:26px 0 10px;letter-spacing:.02em}
.lp-prose p{margin:0 0 16px;color:var(--ink-2);line-height:2}
.lp-prose ul,.lp-prose ol{margin:0 0 18px;padding-left:1.5em;color:var(--ink-2)}
.lp-prose li{margin:6px 0;line-height:1.9}
.lp-prose a{color:var(--green-700)}
.lp-prose a:hover{text-decoration:underline}
.lp-prose__updated{margin-top:36px;font-family:var(--num);color:var(--ink-mute);font-size:12px;text-align:right;letter-spacing:.04em}

/* ===== Form ===== */
.lp-form{
	max-width:680px;margin:0 auto;
	background:var(--card);border:1px solid var(--line);border-radius:var(--radius-lg);
	padding:32px;box-shadow:var(--shadow);
}
.lp-field{margin-bottom:18px}
.lp-field label{display:block;font-weight:600;color:var(--ink);font-size:13px;margin-bottom:8px}
.lp-field .req,.lp-field .opt{
	display:inline-block;font-size:10px;font-weight:600;letter-spacing:.04em;
	padding:2px 7px;border-radius:2px;margin-left:6px;vertical-align:middle;
}
.lp-field .req{background:var(--earth);color:#fff}
.lp-field .opt{background:var(--bg-deep);color:var(--ink-mute)}
.lp-field input,.lp-field textarea{
	width:100%;font:inherit;font-size:14px;color:var(--ink);background:var(--bg);
	border:1px solid var(--line-strong);border-radius:var(--radius);padding:12px 14px;
	transition:border-color .2s,background .2s,box-shadow .2s;
}
.lp-field input:focus,.lp-field textarea:focus{
	outline:none;border-color:var(--green-700);background:#fff;
	box-shadow:0 0 0 3px oklch(0.66 0.12 148 / .15);
}
.lp-field textarea{min-height:160px;resize:vertical}
.lp-form__submit{text-align:center;margin-top:26px}
.lp-form__note{font-size:12px;color:var(--ink-mute);text-align:center;margin-top:18px;line-height:1.85}
.lp-form__note a{color:var(--green-700)}
.lp-hp{position:absolute!important;left:-9999px;width:1px;height:1px;overflow:hidden}
.lp-alert{border-radius:var(--radius);padding:14px 18px;margin-bottom:22px;font-weight:600;font-size:14px}
.lp-alert--ok{background:var(--green-100);border:1px solid var(--green-500);color:var(--green-900)}
.lp-alert--ng{background:oklch(0.96 0.04 30);border:1px solid oklch(0.78 0.12 30);color:oklch(0.40 0.16 30)}
.lp-contactinfo{
	max-width:680px;margin:30px auto 0;
	background:var(--bg-deep);border:1px solid var(--line);border-radius:var(--radius-lg);
	padding:24px 28px;font-size:14px;line-height:2;color:var(--ink-2);
}
.lp-contactinfo b{font-family:var(--serif);font-weight:700;color:var(--ink);display:block;margin-bottom:8px;font-size:14.5px;letter-spacing:.02em}
.lp-contactinfo a{color:var(--green-700)}

/* ===== SDGs ===== */
.lp-sdgs-banner{display:flex;align-items:center;justify-content:center;gap:32px;flex-wrap:nowrap;margin:0 auto}
.lp-sdgs-banner__company img{height:54px;width:auto;display:block}
.lp-sdgs-banner__line{width:1px;height:80px;background:var(--line-strong)}
.lp-sdgs-banner__sdgs img,.lp-sdgs-banner__sdgs .lp-ph{height:88px;width:88px;display:block;border-radius:var(--radius)}
.lp-sdgs-banner__sdgs .lp-ph{
	background:linear-gradient(135deg,var(--green-800),var(--green-700));color:#fff;
	display:flex;align-items:center;justify-content:center;
	font-family:var(--num);font-weight:700;font-size:1rem;letter-spacing:.06em;
}
.lp-sdgs-icons{display:flex;flex-wrap:wrap;justify-content:center;gap:14px;margin-top:36px}
.lp-sdgs-icons img,.lp-sdgs-icons .lp-ph{width:120px;height:120px;border-radius:var(--radius);display:block}
.lp-sdgs-icons img{object-fit:cover}
.lp-sdgs-icons .lp-ph{display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-align:center;padding:10px}
.lp-sdgs-icons .lp-ph b{font-family:var(--num);font-size:1.8rem;font-weight:700;line-height:1}
.lp-sdgs-icons .lp-ph span{font-size:.62rem;font-weight:600;margin-top:7px;line-height:1.35}
.lp-sdgs-note{max-width:780px;margin:30px auto 0;font-size:12px;color:var(--ink-mute);text-align:center;line-height:1.9}
.lp-sdgs-note a{color:var(--green-700);font-weight:600}

/* ===== Hero ===== */
.lp-hero{
	position:relative;overflow:hidden;
	background:linear-gradient(180deg,var(--bg) 0%,var(--bg-deep) 100%);
	isolation:isolate;
}
.lp-hero::before{
	content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;
	background:
		radial-gradient(circle at 80% 30%,oklch(0.78 0.10 150 / .28),transparent 55%),
		radial-gradient(circle at 75% 70%,oklch(0.65 0.12 145 / .18),transparent 60%);
}
.lp-hero::after{
	content:"";position:absolute;inset:0;z-index:-1;opacity:.55;pointer-events:none;
	background-image:
		repeating-linear-gradient(45deg,transparent 0 28px,oklch(0.6 0.08 145 / .05) 28px 29px),
		repeating-linear-gradient(-45deg,transparent 0 28px,oklch(0.6 0.08 145 / .03) 28px 29px);
	-webkit-mask-image:radial-gradient(circle at 75% 40%,black 20%,transparent 70%);
	mask-image:radial-gradient(circle at 75% 40%,black 20%,transparent 70%);
}
.lp-hero__inner{
	position:relative;padding:clamp(60px,11vh,120px) 0 clamp(80px,12vh,140px);
	display:grid;grid-template-columns:1.1fr 1fr;gap:clamp(32px,5vw,64px);align-items:center;
}
.lp-hero__copy{min-width:0}
.lp-hero__art{position:relative;min-width:0}
.lp-hero__art img{
	width:100%;height:auto;display:block;border-radius:var(--radius-lg);
	box-shadow:var(--shadow);object-fit:cover;
}
.lp-hero__art::after{
	content:"";position:absolute;inset:-10px;
	border:1px solid var(--line);border-radius:calc(var(--radius-lg) + 4px);z-index:-1;pointer-events:none;
}
.lp-hero__badge{
	display:inline-flex;align-items:center;gap:10px;
	font-family:var(--num);font-size:11px;font-weight:600;letter-spacing:.22em;text-transform:uppercase;
	color:var(--green-800);margin-bottom:28px;background:transparent;border:0;padding:0;border-radius:0;
}
.lp-hero__badge::before{
	content:"";width:8px;height:8px;border-radius:50%;background:var(--green-700);
	box-shadow:0 0 0 4px oklch(0.66 0.12 148 / .2);
}
.lp-hero h1{
	font-family:var(--serif);font-weight:700;
	font-size:clamp(34px,5.6vw,62px);line-height:1.22;letter-spacing:.01em;
	color:var(--ink);margin-bottom:32px;max-width:20ch;text-wrap:balance;
}
.lp-hero h1 em{
	font-style:normal;color:var(--green-800);
	background-image:linear-gradient(transparent 70%,oklch(0.78 0.13 145 / .35) 70%);
	background-repeat:no-repeat;padding:0 .06em;
}
.lp-hero__sub{
	font-size:clamp(15px,1.3vw,17px);color:var(--ink-2);line-height:2;
	margin-bottom:40px;max-width:36em;text-wrap:pretty;
}
.lp-hero__actions{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:48px}
.lp-hero__btn-tel{
	display:inline-flex;align-items:center;justify-content:center;gap:8px;
	background:var(--card);color:var(--ink);border:1px solid var(--line-strong);
	font-family:var(--num);font-weight:700;text-decoration:none;
	border-radius:999px;padding:14px 28px;font-size:15px;
}
.lp-hero__stats{
	display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0;
	border-top:1px solid var(--line);padding-top:28px;max-width:760px;
}
.lp-hero__stat{
	display:flex;flex-direction:column;gap:6px;padding:4px 18px 4px 0;
	border-right:1px solid var(--line);background:transparent;min-width:0;
}
.lp-hero__stat:last-child{border-right:0}
.lp-hero__stat b{
	font-family:var(--serif);font-weight:700;font-size:22px;line-height:1.2;
	color:var(--green-800);letter-spacing:.02em;
}
.lp-hero__stat span{font-size:11.5px;line-height:1.6;color:var(--ink-mute)}

/* ===== Concerns（悩み） ===== */
.lp-troubles{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:42px}
.lp-trouble{
	background:var(--card);border:1px solid var(--line);border-radius:var(--radius-lg);
	padding:28px 26px;transition:border-color .2s,transform .2s;
}
.lp-trouble:hover{border-color:var(--green-500);transform:translateY(-2px)}
.lp-trouble__mark{
	font-family:var(--serif);font-weight:700;font-size:22px;color:var(--green-700);
	width:44px;height:44px;border-radius:50%;
	background:var(--green-100);border:1px solid var(--green-200);
	display:flex;align-items:center;justify-content:center;margin-bottom:16px;
}
.lp-trouble p{font-family:var(--serif);font-weight:700;color:var(--ink);font-size:16px;line-height:1.7;letter-spacing:.02em}
.lp-troubles__arrow{
	text-align:center;margin-top:34px;
	font-family:var(--num);font-weight:600;font-size:12px;color:var(--green-700);letter-spacing:.18em;
}

/* ===== Products（トップカード） ===== */
.lp-products{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px;margin-top:46px}
.lp-product{
	background:var(--card);border:1px solid var(--line);border-radius:var(--radius-lg);
	overflow:hidden;display:flex;flex-direction:column;
	transition:border-color .2s,transform .2s;
}
.lp-product:hover{border-color:var(--green-500);transform:translateY(-2px)}
.lp-product__img{display:block;width:100%;height:auto;aspect-ratio:16/9;object-fit:cover;background:var(--green-100);border-bottom:1px solid var(--line)}
.lp-product__img-ph{
	width:100%;aspect-ratio:16/9;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;
	background:linear-gradient(135deg,var(--green-100),var(--green-200));border-bottom:1px solid var(--green-200);
}
.lp-product__img-ph b{font-family:var(--serif);font-weight:700;font-size:1.1rem;color:var(--green-900);letter-spacing:.02em;text-align:center;line-height:1.4}
.lp-product__img-ph span{font-family:var(--num);font-size:11px;letter-spacing:.18em;color:var(--ink-mute)}
.lp-product__body{padding:28px 30px 30px;flex:1;display:flex;flex-direction:column}
.lp-product__no{font-family:var(--num);font-weight:700;font-size:10px;letter-spacing:.2em;color:var(--ink-mute);margin-bottom:10px;text-transform:uppercase}
.lp-product h3{font-family:var(--serif);font-weight:700;font-size:22px;color:var(--ink);letter-spacing:.02em;line-height:1.4;margin-bottom:6px}
.lp-product__name{font-family:var(--num);font-weight:600;font-size:14px;color:var(--green-800);letter-spacing:.04em;margin-bottom:14px}
.lp-product p{font-size:14px;line-height:1.95;color:var(--ink-2);margin-bottom:16px;flex:1}
.lp-product ul{list-style:none;padding:0;margin:0 0 18px;display:flex;flex-direction:column;gap:8px}
.lp-product li{position:relative;padding-left:22px;font-size:13.5px;color:var(--ink-2);line-height:1.6}
.lp-product li::before{
	content:"";position:absolute;left:0;top:8px;width:14px;height:7px;
	border-left:1.5px solid var(--green-700);border-bottom:1.5px solid var(--green-700);
	transform:rotate(-45deg);
}
.lp-product__link{
	display:inline-flex;align-items:center;gap:6px;
	font-family:var(--num);font-weight:600;font-size:13px;letter-spacing:.04em;
	color:var(--green-800);padding:10px 0;align-self:flex-start;
	border-bottom:1px solid var(--green-700);transition:gap .2s,color .2s;
}
.lp-product__link:hover{gap:10px;color:var(--green-900)}

/* ===== Product Detail（下層） ===== */
.lp-product-detail{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:start;margin-top:42px}
.lp-product-detail__img img{width:100%;border-radius:var(--radius-lg);box-shadow:var(--shadow)}
.lp-product-detail__img-ph{
	width:100%;aspect-ratio:4/3;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;
	background:linear-gradient(135deg,var(--green-100),var(--green-200));border:1px solid var(--green-200);border-radius:var(--radius-lg);
}
.lp-product-detail__img-ph b{font-family:var(--serif);font-weight:700;font-size:1.5rem;color:var(--green-900);text-align:center;line-height:1.4}
.lp-product-detail__img-ph span{font-family:var(--num);font-size:12px;letter-spacing:.18em;color:var(--ink-mute)}
.lp-product-detail__body h3{font-family:var(--serif);font-weight:700;font-size:clamp(24px,3vw,32px);line-height:1.4;color:var(--ink);margin-bottom:18px;letter-spacing:.02em}
.lp-product-detail__body p{color:var(--ink-2);font-size:15px;line-height:2;margin-bottom:14px}
.lp-product-detail__tag{
	display:inline-block;background:var(--accent);color:#fff;
	font-family:var(--num);font-size:11px;font-weight:600;border-radius:999px;
	padding:5px 14px;margin-bottom:16px;letter-spacing:.06em;
}
.lp-product-detail__label{
	display:block;font-family:var(--num);font-weight:600;font-size:11px;
	letter-spacing:.22em;text-transform:uppercase;color:var(--green-700);
	margin:24px 0 10px;
}

/* ===== Reasons（理由カード） ===== */
.lp-reasons{display:grid;grid-template-columns:repeat(2,1fr);gap:20px;margin-top:46px}
.lp-reason{
	display:flex;gap:18px;background:var(--card);
	border:1px solid var(--line);border-radius:var(--radius-lg);
	padding:28px 30px;transition:border-color .2s,transform .2s;
}
.lp-reason:hover{border-color:var(--green-500);transform:translateY(-2px)}
.lp-reason__num{
	flex:0 0 44px;height:44px;
	background:var(--green-800);color:#fff;
	font-family:var(--num);font-weight:700;font-size:15px;letter-spacing:.02em;
	border-radius:var(--radius);
	display:flex;align-items:center;justify-content:center;
}
.lp-reason h3{font-family:var(--serif);font-weight:700;font-size:18px;color:var(--ink);letter-spacing:.02em;margin-bottom:8px;line-height:1.5}
.lp-reason p{color:var(--ink-2);font-size:14px;line-height:1.95}

/* ===== Philosophy（Mission / Vision / Values 暗色帯） ===== */
.lp-philosophy{background:var(--green-900);color:oklch(0.96 0.02 145);position:relative;overflow:hidden}
.lp-philosophy::before{
	content:"";position:absolute;inset:0;pointer-events:none;
	background:
		radial-gradient(circle at 90% 0%,oklch(0.85 0.13 145 / .14),transparent 50%),
		radial-gradient(circle at 0% 100%,oklch(0.65 0.10 80 / .12),transparent 50%);
}
.lp-philosophy > .lp-wrap{position:relative;z-index:1}
.lp-philosophy .lp-eyebrow{color:oklch(0.85 0.05 145)}
.lp-philosophy .lp-h2{color:#fff}
.lp-philosophy .lp-lead{color:oklch(0.86 0.03 145)}
.lp-block__label{
	display:inline-block;font-family:var(--num);color:oklch(0.85 0.13 145);
	font-weight:600;font-size:11px;letter-spacing:.22em;text-transform:uppercase;margin-bottom:14px;
}
.lp-mission{
	max-width:860px;margin:40px auto 0;text-align:center;
	background:oklch(1 0 0 / .04);border:1px solid oklch(1 0 0 / .12);
	border-radius:var(--radius-lg);padding:48px 32px;
}
.lp-mission__text{
	font-family:var(--serif);font-weight:600;
	font-size:clamp(20px,2.6vw,30px);line-height:1.9;letter-spacing:.04em;
	color:#fff;text-wrap:balance;
}
.lp-mission__text em{font-style:normal;color:oklch(0.92 0.13 145)}
.lp-vision{
	max-width:860px;margin:22px auto 0;text-align:center;
	background:oklch(1 0 0 / .04);border:1px solid oklch(1 0 0 / .12);
	border-radius:var(--radius-lg);padding:30px 32px;
}
.lp-vision p{font-family:var(--serif);font-weight:600;font-size:clamp(17px,2vw,22px);letter-spacing:.04em;color:#fff;line-height:1.7}
.lp-value{max-width:1000px;margin:22px auto 0;text-align:center}
.lp-values{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:14px}
.lp-value-card{
	background:oklch(1 0 0 / .05);border:1px solid oklch(1 0 0 / .12);
	border-radius:var(--radius-lg);padding:24px 18px;
}
.lp-value-card b{
	display:block;font-family:var(--serif);font-weight:700;
	color:oklch(0.92 0.13 145);font-size:1.1rem;letter-spacing:.04em;margin-bottom:10px;
}
.lp-value-card p{font-size:12.5px;color:oklch(0.88 0.03 145);line-height:1.8}

/* ===== Feature（画像＋本文 2カラム） ===== */
.lp-feature{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;margin-top:46px}
.lp-feature__img img{width:100%;border-radius:var(--radius-lg);box-shadow:var(--shadow)}
.lp-feature__body h3{font-family:var(--serif);font-weight:700;font-size:24px;color:var(--ink);letter-spacing:.02em;line-height:1.5;margin-bottom:14px}
.lp-feature__body p{color:var(--ink-2);font-size:15px;line-height:2;margin-bottom:12px}
.lp-feature__list{list-style:none;padding:0;margin-top:18px;display:flex;flex-direction:column;gap:10px}
.lp-feature__list li{position:relative;padding:6px 0 6px 28px;color:var(--ink);font-weight:600;font-size:14.5px;line-height:1.7}
.lp-feature__list li::before{
	content:"";position:absolute;left:0;top:13px;width:14px;height:7px;
	border-left:1.5px solid var(--green-700);border-bottom:1.5px solid var(--green-700);transform:rotate(-45deg);
}

/* ===== Flow ===== */
.lp-flow{
	display:grid;grid-template-columns:repeat(4,1fr);gap:0;margin-top:46px;
	border:1px solid var(--line);border-radius:var(--radius-lg);background:var(--card);overflow:hidden;
}
.lp-flow__step{padding:32px 24px;position:relative;border-right:1px solid var(--line)}
.lp-flow__step:last-child{border-right:0}
.lp-flow__step::after{
	content:"";position:absolute;right:-9px;top:50%;width:16px;height:16px;
	border-top:1px solid var(--line-strong);border-right:1px solid var(--line-strong);
	transform:translateY(-50%) rotate(45deg);background:var(--card);z-index:1;
}
.lp-flow__step:last-child::after{display:none}
.lp-flow__step b{
	display:inline-block;font-family:var(--num);font-weight:700;font-size:11px;letter-spacing:.16em;
	color:var(--green-700);margin-bottom:10px;background:transparent;padding:0;border-radius:0;text-transform:uppercase;
}
.lp-flow__step h4{font-family:var(--serif);font-weight:700;font-size:18px;color:var(--ink);letter-spacing:.04em;margin-bottom:8px;line-height:1.5}
.lp-flow__step p{color:var(--ink-2);font-size:13px;line-height:1.9}

/* ===== Company table ===== */
.lp-company{
	background:var(--card);border:1px solid var(--line);border-radius:var(--radius-lg);
	overflow:hidden;margin-top:34px;
}
.lp-company table{width:100%;border-collapse:collapse}
.lp-company th,.lp-company td{
	text-align:left;padding:18px 24px;border-bottom:1px solid var(--line);
	font-size:14px;line-height:1.85;vertical-align:top;
}
.lp-company th{
	background:var(--bg-deep);color:var(--ink);font-family:var(--serif);font-weight:700;font-size:13.5px;
	width:32%;white-space:nowrap;border-right:1px solid var(--line);letter-spacing:.02em;
}
.lp-company td{color:var(--ink-2);font-family:var(--sans)}
.lp-company td a{color:var(--green-700)}
.lp-company td a:hover{text-decoration:underline}
.lp-company tr:last-child th,.lp-company tr:last-child td{border-bottom:0}

/* ===== Quote ===== */
.lp-quote{
	max-width:860px;margin:34px auto 0;
	background:var(--green-100);border-left:3px solid var(--green-700);
	border-radius:0 var(--radius-lg) var(--radius-lg) 0;padding:28px 32px;
}
.lp-quote p{font-family:var(--serif);font-weight:600;color:var(--green-900);font-size:16px;line-height:1.95;letter-spacing:.02em}

/* ===== CTA ===== */
.lp-cta{background:var(--green-900);color:oklch(0.96 0.02 145);text-align:center;position:relative;overflow:hidden}
.lp-cta::before{
	content:"";position:absolute;inset:0;pointer-events:none;
	background:
		radial-gradient(circle at 80% 20%,oklch(0.65 0.13 145 / .25),transparent 50%),
		radial-gradient(circle at 20% 80%,oklch(0.55 0.08 60 / .18),transparent 55%);
}
.lp-cta > .lp-wrap{position:relative;z-index:1}
.lp-cta h2{
	font-family:var(--serif);font-weight:700;color:#fff;
	font-size:clamp(24px,3.4vw,38px);letter-spacing:.04em;margin-bottom:14px;text-wrap:balance;line-height:1.4;
}
.lp-cta p{color:oklch(0.88 0.03 145);margin-bottom:34px;font-size:15px;line-height:1.9}
.lp-cta__actions{display:flex;flex-wrap:wrap;gap:16px;justify-content:center}
.lp-cta__tel{
	display:inline-flex;flex-direction:column;align-items:center;
	background:#fff;color:var(--green-900);border-radius:var(--radius-lg);
	padding:14px 36px;text-decoration:none;
}
.lp-cta__tel small{font-family:var(--num);font-size:11px;color:var(--ink-mute);font-weight:600;letter-spacing:.08em;text-transform:uppercase}
.lp-cta__tel b{font-family:var(--num);font-size:22px;font-weight:700;letter-spacing:.02em;color:var(--green-900);margin-top:2px}

/* ===== Footer ===== */
.lp-footer{background:oklch(0.18 0.02 150);color:oklch(0.78 0.02 140);padding:56px 0 30px}
.lp-footer__top{display:grid;grid-template-columns:1.3fr 1fr;gap:32px;align-items:start}
.lp-footer__name{
	font-family:var(--serif);font-weight:700;color:#fff;font-size:18px;letter-spacing:.02em;margin-bottom:10px;
}
.lp-footer__contact{font-size:12.5px;line-height:2;color:oklch(0.75 0.02 145)}
.lp-footer__nav{display:flex;flex-wrap:wrap;gap:14px 24px;justify-content:flex-end;align-content:flex-start;max-width:none}
.lp-footer__nav a{color:oklch(0.78 0.02 145);font-size:13px;letter-spacing:.02em;transition:color .2s}
.lp-footer__nav a:hover{color:#fff}
.lp-footer__copy{
	margin-top:30px;padding-top:22px;border-top:1px solid oklch(0.30 0.02 150);
	font-family:var(--num);font-size:11px;letter-spacing:.06em;color:oklch(0.6 0.02 145);text-align:center;
}

/* ===== Sticky（モバイル下部固定） ===== */
.lp-sticky{display:none}

/* ===== Amazon badge ===== */
.lp-amazon{
	display:inline-flex;align-items:center;gap:8px;
	background:#ff9900;color:#fff;border-radius:var(--radius);
	padding:10px 18px;font-family:var(--num);font-weight:700;font-size:13px;letter-spacing:.04em;
	text-decoration:none;margin-top:14px;
}
.lp-amazon:hover{filter:brightness(1.06)}

/* ===== Responsive ===== */
@media(max-width:1024px){
	.lp-bar__tel{display:none}
}
@media(max-width:860px){
	.lp-section{padding:60px 0}
	.lp-troubles,.lp-products,.lp-reasons,.lp-feature,.lp-product-detail{grid-template-columns:1fr}
	.lp-values{grid-template-columns:repeat(2,1fr)}
	.lp-hero__inner{grid-template-columns:1fr;gap:36px}
	.lp-hero__art{order:-1;max-width:520px;margin:0 auto;width:100%}
	.lp-hero__stats{grid-template-columns:repeat(2,1fr);padding-top:22px;row-gap:14px}
	.lp-hero__stat{padding:8px 14px 8px 0;border-right:1px solid var(--line)}
	.lp-hero__stat:nth-child(2n){border-right:0}
	.lp-sdgs-banner{gap:18px}
	.lp-sdgs-banner__company img{height:36px}
	.lp-sdgs-banner__line{height:64px}
	.lp-sdgs-banner__sdgs img,.lp-sdgs-banner__sdgs .lp-ph{height:72px;width:72px}
	.lp-sdgs-icons img,.lp-sdgs-icons .lp-ph{width:96px;height:96px}

	.lp-company{margin-top:24px}
	.lp-company table,.lp-company tbody,.lp-company tr,.lp-company th,.lp-company td{display:block;width:100%}
	.lp-company th{
		background:transparent;white-space:normal;border-bottom:0;border-right:0;
		padding:15px 18px 4px;font-size:11px;font-family:var(--num);font-weight:700;
		color:var(--green-700);letter-spacing:.16em;text-transform:uppercase;
	}
	.lp-company td{padding:0 18px 16px;border-bottom:1px solid var(--line);font-size:14px;line-height:1.85;word-break:break-word}
	.lp-company tr:last-child td{border-bottom:0}

	.lp-bar__inner{height:62px}
	.lp-logo img{height:40px}
	.lp-bar__right{gap:8px}
	.lp-bar__cta{display:none}
	.lp-lang__btn{padding:5px 9px;font-size:10px}
	.lp-burger{display:flex}
	.lp-gnav{max-height:0;overflow:hidden;transition:max-height .28s ease;border-top:0}
	.lp-nav-toggle:checked ~ .lp-gnav{max-height:560px;border-top:1px solid var(--line)}
	.lp-gnav__inner{flex-direction:column}
	.lp-gnav__link{flex:none;text-align:left;padding:14px 24px;border-bottom:1px solid var(--line)}
	.lp-gnav__link:hover::after,.lp-gnav__link.is-current::after{left:24px;right:24px;bottom:8px}
	.lp-nav-toggle:checked ~ .lp-bar .lp-burger span:nth-child(1){transform:translateY(7px) rotate(45deg)}
	.lp-nav-toggle:checked ~ .lp-bar .lp-burger span:nth-child(2){opacity:0}
	.lp-nav-toggle:checked ~ .lp-bar .lp-burger span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}

	.lp-flow{grid-template-columns:repeat(2,1fr)}
	.lp-flow__step{border-right:1px solid var(--line);border-bottom:1px solid var(--line)}
	.lp-flow__step:nth-child(2){border-right:0}
	.lp-flow__step:nth-child(3),.lp-flow__step:nth-child(4){border-bottom:0}
	.lp-flow__step::after{display:none}

	.lp-footer__top{grid-template-columns:1fr}
	.lp-footer__nav{justify-content:flex-start}

	body.lp-body{padding-bottom:72px}
	.lp-sticky{
		display:flex;position:fixed;left:0;right:0;bottom:0;z-index:60;
		box-shadow:0 -4px 16px oklch(0 0 0 / .12);
	}
	.lp-sticky a{
		flex:1;display:flex;align-items:center;justify-content:center;gap:6px;
		padding:14px 8px;font-family:var(--num);font-weight:700;text-decoration:none;font-size:14px;letter-spacing:.02em;
	}
	.lp-sticky__tel{background:var(--green-900);color:#fff}
	.lp-sticky__form{background:var(--green-700);color:#fff}
}
@media(max-width:560px){
	.lp-flow{grid-template-columns:1fr}
	.lp-flow__step,.lp-flow__step:nth-child(n){border-right:0;border-bottom:1px solid var(--line)}
	.lp-flow__step:last-child{border-bottom:0}
}
</style>
</head>
<body <?php body_class( trim( 'lp-body ' . $body_class ) ); ?>>
	<?php
}

/**
 * 共通ヘッダー（グローバルナビ）を出力。
 *
 * @param string $current 現在ページのキー（lp_cfg の nav キー）。
 */
function lp_header( $current = '' ) {
	$cfg   = lp_cfg();
	$is_en = ( 'en' === lp_lang() );
	?>
<header class="lp-header">
	<input type="checkbox" id="lp-nav" class="lp-nav-toggle">
	<div class="lp-bar">
		<div class="lp-wrap lp-bar__inner">
			<?php $lp_logo_src = lp_company_logo_url(); ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="lp-logo">
				<?php if ( $lp_logo_src ) : ?>
					<img src="<?php echo esc_url( $lp_logo_src ); ?>" alt="<?php echo esc_attr( lp_company_name() ); ?>">
				<?php else : ?>
					<div class="lp-logo__text">
						<?php echo esc_html( lp_company_name() ); ?>
						<small>SAISEI KEIKAKU ・ SUSTAINABLE AGRICULTURE</small>
					</div>
				<?php endif; ?>
			</a>
			<div class="lp-bar__right">
				<div class="lp-lang" role="group" aria-label="<?php echo esc_attr( lp_t( '言語', 'Language' ) ); ?>">
					<button type="button" class="lp-lang__btn<?php echo $is_en ? '' : ' is-active'; ?>" data-lang="ja">日本語</button>
					<button type="button" class="lp-lang__btn<?php echo $is_en ? ' is-active' : ''; ?>" data-lang="en">EN</button>
				</div>
				<?php if ( $cfg['tel_link'] ) : ?>
				<a href="tel:<?php echo esc_attr( $cfg['tel_link'] ); ?>" class="lp-bar__tel">
					<small><?php echo esc_html( lp_t( 'お電話でのお問い合わせ', 'Call us' ) ); ?></small><b><?php echo esc_html( $cfg['tel'] ); ?></b>
				</a>
				<?php endif; ?>
				<a href="<?php echo esc_url( lp_contact_url() ); ?>" class="lp-btn lp-btn--primary lp-bar__cta"><?php echo esc_html( lp_t( 'お問い合わせ', 'Contact' ) ); ?></a>
				<label for="lp-nav" class="lp-burger" aria-label="<?php echo esc_attr( lp_t( 'メニュー', 'Menu' ) ); ?>"><span></span><span></span><span></span></label>
			</div>
		</div>
	</div>
	<nav class="lp-gnav" aria-label="<?php echo esc_attr( lp_t( 'グローバルナビ', 'Global navigation' ) ); ?>">
		<div class="lp-wrap lp-gnav__inner">
			<?php
			foreach ( $cfg['nav'] as $key => $item ) {
				$cls   = 'lp-gnav__link' . ( $key === $current ? ' is-current' : '' );
				$label = $is_en && isset( $item['en'] ) ? $item['en'] : $item['ja'];
				printf(
					'<a class="%s" href="%s">%s</a>',
					esc_attr( $cls ),
					esc_url( lp_page_url( $item['path'] ) ),
					esc_html( $label )
				);
			}
			?>
		</div>
	</nav>
</header>
	<?php
}

/**
 * 下層ページ用のページヘッダー＋パンくずを出力。
 */
function lp_pagehead( $en, $title ) {
	?>
<section class="lp-pagehead">
	<div class="lp-wrap">
		<span class="lp-pagehead__en"><?php echo esc_html( $en ); ?></span>
		<h1><?php echo esc_html( $title ); ?></h1>
	</div>
</section>
<div class="lp-breadcrumb">
	<div class="lp-wrap">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( lp_t( 'ホーム', 'Home' ) ); ?></a><span>›</span><?php echo esc_html( $title ); ?>
	</div>
</div>
	<?php
}

/** 共通CTAバンドを出力。 */
function lp_cta() {
	$cfg = lp_cfg();
	?>
<section class="lp-section lp-cta">
	<div class="lp-wrap">
		<h2><?php echo esc_html( lp_t( '製品に関するご相談・お問い合わせはこちら', 'Talk to us about our products.' ) ); ?></h2>
		<p><?php echo esc_html( lp_t( 'ご購入・使用方法・農地への適用についてお気軽にご連絡ください。', 'Feel free to reach out about purchasing, usage, or applying to your farmland.' ) ); ?></p>
		<div class="lp-cta__actions">
			<a href="<?php echo esc_url( lp_contact_url() ); ?>" class="lp-btn lp-btn--primary lp-btn--lg"><?php echo esc_html( lp_t( 'お問い合わせフォームへ', 'Go to the contact form' ) ); ?></a>
			<?php if ( $cfg['tel_link'] ) : ?>
			<a href="tel:<?php echo esc_attr( $cfg['tel_link'] ); ?>" class="lp-cta__tel">
				<small><?php echo esc_html( lp_t( 'お電話でのご相談', 'Call us' ) ); ?></small><b><?php echo esc_html( $cfg['tel'] ); ?></b>
			</a>
			<?php endif; ?>
		</div>
	</div>
</section>
	<?php
}

/**
 * 共通フッター＋スマホ固定ボタン＋</body></html> を出力。
 */
function lp_footer( $show_sticky = true ) {
	$cfg = lp_cfg();
	?>
<footer class="lp-footer">
	<div class="lp-wrap">
		<div class="lp-footer__top">
			<div>
				<div class="lp-footer__name"><?php echo esc_html( lp_company_name() ); ?></div>
				<div class="lp-footer__contact">
					<?php echo esc_html( lp_cf( 'address' ) ); ?><br>
					<?php if ( $cfg['tel'] ) : ?>
					TEL：<?php echo esc_html( $cfg['tel'] ); ?><?php if ( $cfg['fax'] ) { echo '　/　FAX：' . esc_html( $cfg['fax'] ); } ?><br>
					<?php endif; ?>
					<?php if ( $cfg['mail'] ) : ?>
					MAIL：<?php echo esc_html( $cfg['mail'] ); ?>
					<?php endif; ?>
				</div>
			</div>
			<nav class="lp-footer__nav" aria-label="<?php echo esc_attr( lp_t( 'フッターナビ', 'Footer navigation' ) ); ?>">
				<?php
				$is_en = ( 'en' === lp_lang() );
				foreach ( $cfg['nav'] as $item ) {
					$label = $is_en && isset( $item['en'] ) ? $item['en'] : $item['ja'];
					printf(
						'<a href="%s">%s</a>',
						esc_url( lp_page_url( $item['path'] ) ),
						esc_html( $label )
					);
				}
				?>
			</nav>
		</div>
		<div class="lp-footer__copy">
			&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php echo esc_html( lp_company_name() ); ?> <?php echo esc_html( lp_t( '無断複製を禁じます。', 'All Rights Reserved.' ) ); ?>
		</div>
	</div>
</footer>
	<?php if ( $show_sticky ) : ?>
<div class="lp-sticky">
	<?php if ( $cfg['tel_link'] ) : ?>
	<a href="tel:<?php echo esc_attr( $cfg['tel_link'] ); ?>" class="lp-sticky__tel">&#9990; <?php echo esc_html( lp_t( '電話する', 'Call' ) ); ?></a>
	<?php endif; ?>
	<a href="<?php echo esc_url( lp_contact_url() ); ?>" class="lp-sticky__form">&#9993; <?php echo esc_html( lp_t( 'お問い合わせ', 'Contact' ) ); ?></a>
</div>
	<?php endif; ?>
<script>
/* 言語切替: Cookie に保存し、ページ遷移後も選択を維持 */
(function(){
	var btns=document.querySelectorAll('.lp-lang__btn');
	for(var i=0;i<btns.length;i++){
		btns[i].addEventListener('click',function(){
			if(this.classList.contains('is-active'))return;
			var lang=this.getAttribute('data-lang')==='en'?'en':'ja';
			document.cookie='lp_lang='+lang+';path=/;max-age=31536000;samesite=lax';
			location.reload();
		});
	}
})();
</script>
<?php
	wp_footer();
	echo "\n</body>\n</html>";
}
