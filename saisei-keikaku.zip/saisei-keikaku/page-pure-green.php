<?php
/**
 * Template Name: 植物活性液（再生計画）
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';
$cfg = lp_cfg();

lp_head(
	lp_t( '植物活性液ピュアグリン（Pure Green）', 'Pure Green — Plant Activator' ),
	lp_t(
		'野菜の甘みを引き出す植物活性液「ピュアグリン（Pure Green）」。苦味・エグ味の元となる硝酸態窒素を低減し、野菜本来の味わいを引き立てます。',
		'Pure Green — a plant activator that draws out the natural sweetness of vegetables by reducing nitrate nitrogen, the source of bitterness.'
	)
);
lp_header( 'green' );
lp_pagehead( 'PLANT ACTIVATOR', lp_t( '植物活性液 ピュアグリン', 'Pure Green — Plant Activator' ) );
?>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-product-detail">
			<div class="lp-product-detail__img">
				<?php if ( lp_asset_exists( 'images/lp/lp-pure-green.png' ) ) : ?>
					<img src="<?php echo esc_url( lp_asset_url( 'images/lp/lp-pure-green.png' ) ); ?>" alt="<?php echo esc_attr( lp_t( '植物活性液ピュアグリン', 'Pure Green plant activator' ) ); ?>" loading="lazy" width="1280" height="960">
				<?php else : ?>
					<div class="lp-product-detail__img-ph"><b><?php echo esc_html( lp_t( 'ピュアグリン', 'Pure Green' ) ); ?></b><span>Pure Green</span></div>
				<?php endif; ?>
			</div>
			<div class="lp-product-detail__body">
				<span class="lp-product-detail__tag"><?php echo esc_html( lp_t( '植物活性液', 'Plant Activator' ) ); ?></span>
				<h3><?php echo wp_kses_post( lp_t( '植物活性液<br>ピュアグリン（Pure Green）', 'Plant Activator<br>Pure Green' ) ); ?></h3>
				<p><?php echo esc_html( lp_t(
					'野菜の甘みを引き出す、健康と環境に優しい植物活性液です。野菜に含まれる硝酸態窒素は苦味・エグ味の元。ピュアグリンを散布するとこの成分が低減され、野菜本来の甘みと味わいが際立ちます。',
					'A plant activator that draws out the natural sweetness of vegetables — gentle on people and the environment. Nitrate nitrogen in vegetables is the source of bitterness; spraying Pure Green reduces it, letting true sweetness and flavor stand out.'
				) ); ?></p>
				<p><?php echo esc_html( lp_t(
					'「持続可能」と「循環型」という理念のもと、食品を主体とした天然の植物成分で開発しました。肌にもやさしく、特別な技能を必要とせず、葉に吹きかけるだけで誰でも簡単にご利用いただけます。',
					'Built on the principles of "sustainable" and "cyclical", it is made from food-grade natural plant ingredients. Gentle on skin, no special skill required — anyone can use it with just a spray on the leaves.'
				) ); ?></p>
				<span class="lp-product-detail__label">FEATURES</span>
				<ul style="list-style:none;padding:0;">
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '苦味・エグ味の元となる硝酸態窒素を低減', 'Reduces nitrate nitrogen — the source of bitterness and harshness.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '野菜本来の甘み・味わいを引き立てる', 'Brings out natural sweetness and flavor.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '植物の代謝を高め、成長促進が期待できる', 'Boosts plant metabolism — supports growth.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '葉のpHを保ち、防虫効果も期待できる', 'Maintains leaf pH and offers pest-deterrent effects.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '食品由来の天然植物成分で人にも環境にもやさしい', 'Food-derived natural plant ingredients — gentle on people and environment.' ) ); ?></li>
				</ul>
			</div>
		</div>
	</div>
</section>

<section class="lp-section lp-section--soft">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">BACKGROUND</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '硝酸態窒素とは', 'What is nitrate nitrogen?' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '野菜の味と健康に関わる、知っておきたい成分のはなし。', 'A compound worth knowing — for both vegetable flavor and health.' ) ); ?></p>
		</div>
		<div class="lp-feature">
			<div class="lp-feature__img">
				<?php if ( lp_asset_exists( 'images/lp/lp-field.png' ) ) : ?>
					<img src="<?php echo esc_url( lp_asset_url( 'images/lp/lp-field.png' ) ); ?>" alt="<?php echo esc_attr( lp_t( '農場の様子', 'Farm field' ) ); ?>" loading="lazy" width="1280" height="720">
				<?php else : ?>
					<div style="background:linear-gradient(135deg,var(--green-light),#c8e6c9);border-radius:var(--radius);aspect-ratio:16/9;display:flex;align-items:center;justify-content:center;"><span style="color:var(--green-dark);font-weight:800;"><?php echo esc_html( lp_t( '農場イメージ', 'Farm field image' ) ); ?></span></div>
				<?php endif; ?>
			</div>
			<div class="lp-feature__body">
				<h3><?php echo esc_html( lp_t( '硝酸態窒素は野菜の「苦味・エグ味」の元', 'Nitrate nitrogen — the source of vegetable bitterness' ) ); ?></h3>
				<p><?php echo esc_html( lp_t(
					'硝酸態窒素は、化学肥料などに由来して野菜に蓄積する成分です。これを多く含む野菜は苦味やエグ味が強くなり、野菜本来の味わいを損なってしまいます。',
					'Nitrate nitrogen comes from chemical fertilizers and other sources and accumulates in vegetables. When present in large amounts, it produces strong bitterness and harshness, masking the true flavor.'
				) ); ?></p>
				<p><?php echo esc_html( lp_t(
					'ピュアグリンを散布すると、この硝酸態窒素が低減されます。実際にキャベツでは、散布の翌日に硝酸値が約20分の1まで下がった例もあり、隠れていた甘みや旨みが引き立ちます。',
					'Spraying Pure Green reduces this nitrate. In cabbage, nitrate has fallen to roughly one-twentieth the day after spraying — letting hidden sweetness and umami come through.'
				) ); ?></p>
				<ul class="lp-feature__list">
					<li><?php echo esc_html( lp_t( '苦味・エグ味の元となる硝酸態窒素を低減', 'Reduces nitrate nitrogen — the source of bitterness and harshness.' ) ); ?></li>
					<li><?php echo esc_html( lp_t( '野菜本来の甘み・旨みが際立つ', 'Natural sweetness and umami stand out.' ) ); ?></li>
					<li><?php echo esc_html( lp_t( '乳児を中心とした健康への配慮にもつながる', 'Supports health considerations — particularly for infants.' ) ); ?></li>
				</ul>
			</div>
		</div>
	</div>
</section>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">HOW TO USE</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '使用方法', 'How to use' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '特別な技能を必要とせず、誰でも簡単にお使いいただけます。', 'No special skills required — anyone can apply it easily.' ) ); ?></p>
		</div>
		<div class="lp-flow">
			<div class="lp-flow__step">
				<b>STEP 1</b>
				<h4><?php echo esc_html( lp_t( '希釈する', 'Dilute' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( '作物に直接散布する場合は、必ず200倍以上に薄めてご使用ください。', 'When spraying directly on crops, always dilute 200× or more.' ) ); ?></p>
			</div>
			<div class="lp-flow__step">
				<b>STEP 2</b>
				<h4><?php echo esc_html( lp_t( '葉に吹きかける', 'Spray on leaves' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( '希釈した液を、葉にシュシュッと吹きかけます。', 'Mist the diluted liquid onto the leaves.' ) ); ?></p>
			</div>
			<div class="lp-flow__step">
				<b>STEP 3</b>
				<h4><?php echo esc_html( lp_t( '目的に合わせて', 'Match the purpose' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( '甘みを引き出すなら収穫の2日前、成長促進なら水やりの際に散布します。', 'For sweetness: spray 2 days before harvest. For growth: spray when watering.' ) ); ?></p>
			</div>
			<div class="lp-flow__step">
				<b>STEP 4</b>
				<h4><?php echo esc_html( lp_t( '効果を確認', 'Check results' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( '野菜の味わいや生育の変化をご確認ください。', 'Check changes in flavor and growth.' ) ); ?></p>
			</div>
		</div>
		<div class="lp-quote" style="margin-top:40px;">
			<p><?php echo esc_html( lp_t(
				'200倍以下の濃度で散布すると作物を枯らす恐れがあります（リンゴは例外）。アルカリ性の農薬との混用は避けてください。天候や作物の状況によって効果が異なる場合があります。詳しい使用量・注意事項は、製品に同梱の説明書、または当社へのお問い合わせをご確認ください。',
				'Spraying at less than 200× dilution may damage crops (apples are an exception). Do not mix with alkaline pesticides. Results may vary with weather and crop conditions. For detailed dosage and precautions, see the included instructions or contact us.'
			) ); ?></p>
		</div>
	</div>
</section>

<section class="lp-section lp-section--soft">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">SPECIFICATIONS</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '製品仕様', 'Specifications' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '植物活性液 ピュアグリン（Pure Green）の基本仕様です。', 'Basic specifications of Pure Green plant activator.' ) ); ?></p>
		</div>
		<div class="lp-company" style="margin-top:34px;">
			<table>
				<tbody>
					<tr><th><?php echo esc_html( lp_t( '製品名', 'Product name' ) ); ?></th><td><?php echo esc_html( lp_t( 'ピュアグリン（Pure Green）', 'Pure Green' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '分類', 'Category' ) ); ?></th><td><?php echo esc_html( lp_t( '植物活性液', 'Plant activator liquid' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '主原料', 'Main ingredients' ) ); ?></th><td><?php echo esc_html( lp_t( 'アルコール、玄米', 'Alcohol, brown rice' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '内容量', 'Volume' ) ); ?></th><td>20L</td></tr>
					<tr><th><?php echo esc_html( lp_t( '用途', 'Use' ) ); ?></th><td><?php echo esc_html( lp_t( '主に農園芸作物に対する植物活性・病虫害の防除資材として', 'Primarily as a plant activator and pest/disease control material for agricultural and horticultural crops.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '保存方法', 'Storage' ) ); ?></th><td><?php echo esc_html( lp_t( '直射日光を避けて保存してください', 'Store away from direct sunlight.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '英語版（English）', 'English version' ) ); ?></th><td><?php echo esc_html( lp_t( '英語版「PureGreen」の情報もご用意しています。お問い合わせフォームよりお気軽にご連絡ください。', 'English information for "PureGreen" is also available. Please contact us via the inquiry form.' ) ); ?></td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<?php lp_cta(); ?>
<?php lp_footer(); ?>
