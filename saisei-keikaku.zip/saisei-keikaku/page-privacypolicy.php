<?php
/**
 * Template Name: プライバシーポリシー（再生計画）
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';
$cfg = lp_cfg();

lp_head(
	lp_t( 'プライバシーポリシー', 'Privacy Policy' ),
	lp_t(
		'有限会社再生計画のプライバシーポリシー。お預かりした個人情報の利用目的・安全管理・訂正削除の取り扱いについてご説明します。',
		'Saisei Keikaku Co., Ltd. Privacy Policy — explaining how we use, safeguard, correct and delete the personal information entrusted to us.'
	)
);
lp_header( 'privacy' );
lp_pagehead( 'PRIVACY POLICY', lp_t( 'プライバシーポリシー', 'Privacy Policy' ) );
?>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-prose">
			<?php if ( 'en' === lp_lang() ) : ?>
				<p><?php echo esc_html( lp_company_name() ); ?> ("the Company") recognizes the importance of the personal information entrusted to it by customers, and is committed to protecting and handling it appropriately.</p>

				<h2>1. Use of Personal Information</h2>
				<p>The Company uses personal information entrusted by customers for the following purposes:</p>
				<ul>
					<li>To confirm or follow up on inquiries and consultations</li>
					<li>To contact customers regarding product purchase or delivery</li>
					<li>To respond to inquiries</li>
					<li>For surveys regarding product improvement and new product development</li>
				</ul>
				<p>The Company will not disclose or provide your personal information to any third party except in the following cases:</p>
				<ul>
					<li>Where required by law</li>
					<li>Where necessary to protect a person's life, body or property, and obtaining consent is difficult</li>
					<li>Where provision is needed to a delivery contractor within the scope necessary to ship the product</li>
				</ul>

				<h2>2. Security Management</h2>
				<p>The Company implements reasonable organizational, physical, personnel and technical security measures to prevent unauthorized access, loss, alteration, leakage and other risks to personal data, and handles personal data in accordance with applicable laws.</p>

				<h2>3. Correction and Deletion</h2>
				<p>If you wish to correct or delete the personal information we hold, please contact us at the address below. After verifying your identity, we will respond promptly.</p>

				<h2>4. Contact</h2>
				<p>For inquiries regarding the handling of personal information, please reach out via the <a href="<?php echo esc_url( lp_contact_url() ); ?>">inquiry form</a>.</p>
				<ul>
					<li><?php echo esc_html( lp_company_name() ); ?></li>
					<?php if ( $cfg['address'] ) : ?>
					<li>Address: <?php echo esc_html( lp_cf( 'address' ) ); ?></li>
					<?php endif; ?>
					<?php if ( $cfg['tel'] ) : ?>
					<li>Tel: <?php echo esc_html( $cfg['tel'] ); ?><?php if ( $cfg['fax'] ) { echo ' &nbsp;/&nbsp; Fax: ' . esc_html( $cfg['fax'] ); } ?></li>
					<?php endif; ?>
					<li>Email: <a href="mailto:<?php echo esc_attr( $cfg['mail'] ); ?>"><?php echo esc_html( $cfg['mail'] ); ?></a></li>
				</ul>

				<h2>5. Changes to this Privacy Policy</h2>
				<p>The Company may revise the contents of this Privacy Policy as needed. Revised contents will take effect upon publication on this page.</p>

				<p class="lp-prose__updated">Effective date: January 1, 2024</p>
			<?php else : ?>
				<p><?php echo esc_html( lp_company_name() ); ?>（以下「当社」といいます。）は、お客様からお預かりする個人情報の重要性を認識し、その保護の徹底と適切な取り扱いに努めます。</p>

				<h2>1. 個人情報の利用</h2>
				<p>当社は、お客様からお預かりした個人情報を、次の目的のために利用します。</p>
				<ul>
					<li>ご依頼・ご相談内容の確認・照会のため</li>
					<li>製品のご購入・配送に関する連絡のため</li>
					<li>お問い合わせへの回答・ご連絡のため</li>
					<li>製品改善・新製品開発に関するアンケートのため</li>
				</ul>
				<p>当社は、次の場合を除き、お客様の個人情報を第三者へ開示・提供することはありません。</p>
				<ul>
					<li>法令に基づく場合</li>
					<li>人の生命・身体・財産の保護に必要であり、本人の同意を得ることが困難な場合</li>
					<li>商品の配送に必要な範囲で配送業者へ提供する場合</li>
				</ul>

				<h2>2. 個人情報の安全管理</h2>
				<p>当社は、個人データへの不正アクセス、紛失、改ざん、漏えい等を防止するため、合理的・組織的・物理的・人的・技術的な安全管理措置を講じるとともに、関連法令に準じた適切な取り扱いを行います。</p>

				<h2>3. 個人情報の訂正・削除</h2>
				<p>お預かりしている個人情報の訂正・削除をご希望の場合は、下記のお問い合わせ先までご連絡ください。ご本人であることを確認のうえ、速やかに対応いたします。</p>

				<h2>4. お問い合わせ先</h2>
				<p>個人情報の取り扱いに関するお問い合わせは、<a href="<?php echo esc_url( lp_contact_url() ); ?>">お問い合わせフォーム</a>よりご連絡ください。</p>
				<ul>
					<li><?php echo esc_html( lp_company_name() ); ?></li>
					<?php if ( $cfg['address'] ) : ?>
					<li>所在地：<?php echo esc_html( lp_cf( 'address' ) ); ?></li>
					<?php endif; ?>
					<?php if ( $cfg['tel'] ) : ?>
					<li>TEL：<?php echo esc_html( $cfg['tel'] ); ?><?php if ( $cfg['fax'] ) { echo '　/　FAX：' . esc_html( $cfg['fax'] ); } ?></li>
					<?php endif; ?>
					<li>メール：<a href="mailto:<?php echo esc_attr( $cfg['mail'] ); ?>"><?php echo esc_html( $cfg['mail'] ); ?></a></li>
				</ul>

				<h2>5. プライバシーポリシーの変更</h2>
				<p>当社は、本プライバシーポリシーの内容を必要に応じて変更することがあります。変更後の内容は、当ページに掲載した時点から効力を生じるものとします。</p>

				<p class="lp-prose__updated">制定日：2024年1月1日</p>
			<?php endif; ?>
		</div>
	</div>
</section>

<?php lp_footer(); ?>
