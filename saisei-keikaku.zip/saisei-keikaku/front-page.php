<?php
/**
 * front-page.php ─ サイトのトップページ（ランディングページ）
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';

$cfg         = lp_cfg();
$lp_tel      = $cfg['tel'];
$lp_tel_link = $cfg['tel_link'];
$lp_img      = $cfg['img'];
$lp_contact  = lp_contact_url();

lp_head(
	lp_t( '持続可能な農業を支える植物活性液・有機肥料', 'Plant Activator & Organic Fertilizer for Sustainable Agriculture' ),
	lp_t(
		'有限会社再生計画は「持続可能」と「循環型」をキーワードに、植物活性液ピュアグリンと植物性有機肥料オーガニックピュアブラウンを開発・販売しています。',
		'Saisei Keikaku Co., Ltd. develops and sells Pure Green plant activator and Organic Pure Brown plant-based fertilizer under the keywords "sustainable" and "cyclical".'
	)
);
lp_header( 'home' );
?>

<?php /* ========== Hero ========== */ ?>
<section class="lp-hero" id="top">
	<div class="lp-wrap lp-hero__inner">
		<div class="lp-hero__copy">
		<span class="lp-hero__badge"><?php echo esc_html( lp_t( 'SDGsへの取り組み ／ 持続可能な農業', 'SDGs commitment / Sustainable agriculture' ) ); ?></span>
		<h1>
			<?php if ( 'en' === lp_lang() ) : ?>
				Connecting agriculture<br />to <em>the future.</em><br />Healthy crops, by sustainable<br />and cyclical means.
			<?php else : ?>
				農業を、<em>未来へ</em>つなぐ。<br>「持続可能」と「循環型」で<br>健康な作物を育てる
			<?php endif; ?>
		</h1>
		<p class="lp-hero__sub">
			<?php
			echo wp_kses_post( lp_t(
				'食の安全と農業の持続可能性を両立する、独自の植物活性液・有機肥料をお届けします。<br>特別な技能を必要とせず、誰でも簡単に使えます。',
				'We deliver distinctive plant activator liquid and organic fertilizer that balance food safety with agricultural sustainability.<br>No special skill required — anyone can use them.'
			) );
			?>
		</p>
		<div class="lp-hero__actions">
			<a href="<?php echo esc_url( lp_page_url( 'pure-green' ) ); ?>" class="lp-btn lp-btn--primary lp-btn--lg"><?php echo esc_html( lp_t( '植物活性液を見る', 'View Plant Activator' ) ); ?></a>
			<a href="<?php echo esc_url( lp_page_url( 'organic-brown' ) ); ?>" class="lp-btn lp-btn--accent lp-btn--lg"><?php echo esc_html( lp_t( '有機肥料を見る', 'View Organic Fertilizer' ) ); ?></a>
		</div>
		<div class="lp-hero__stats">
			<div class="lp-hero__stat"><b><?php echo esc_html( lp_t( '持続可能', 'Sustainable' ) ); ?></b><span><?php echo esc_html( lp_t( '環境に配慮した農業資材', 'Eco-conscious farm inputs' ) ); ?></span></div>
			<div class="lp-hero__stat"><b><?php echo esc_html( lp_t( '循環型', 'Cyclical' ) ); ?></b><span><?php echo esc_html( lp_t( '長期利用と再利用をモットーに', 'Built around long-term use and reuse' ) ); ?></span></div>
			<div class="lp-hero__stat"><b>SDGs</b><span><?php echo esc_html( lp_t( '持続可能な開発目標への取り組み', 'Committed to the SDGs' ) ); ?></span></div>
		</div>
		</div><!-- /.lp-hero__copy -->

		<?php if ( lp_asset_exists( 'images/lp/lp-hero.png' ) ) : ?>
		<div class="lp-hero__art">
			<img src="<?php echo esc_url( lp_asset_url( 'images/lp/lp-hero.png' ) ); ?>" alt="<?php echo esc_attr( lp_t( '持続可能と循環型の農業イメージ', 'Sustainable and cyclical agriculture' ) ); ?>" loading="eager">
		</div>
		<?php endif; ?>
	</div>
</section>

<?php /* ========== Concerns ========== */ ?>
<section class="lp-section">
	<div class="lp-wrap lp-center">
		<span class="lp-eyebrow">CONCERNS</span>
		<h2 class="lp-h2"><?php echo esc_html( lp_t( 'こんなお困りごと、ありませんか？', 'Are you facing any of these challenges?' ) ); ?></h2>
		<p class="lp-lead"><?php echo esc_html( lp_t( '農業や家庭菜園では、化学肥料への依存や土壌の疲弊、食の安全への関心など、さまざまな課題があります。', 'In agriculture and home gardening, there are many challenges — reliance on chemical fertilizers, soil exhaustion, concerns over food safety.' ) ); ?></p>
		<div class="lp-troubles">
			<div class="lp-trouble">
				<div class="lp-trouble__mark">?</div>
				<p><?php echo wp_kses_post( lp_t( '野菜の苦味を抑えて<br>甘みを引き出したい', 'Reduce bitterness and<br>bring out vegetable sweetness' ) ); ?></p>
			</div>
			<div class="lp-trouble">
				<div class="lp-trouble__mark">?</div>
				<p><?php echo wp_kses_post( lp_t( '化学肥料に頼らない<br>土づくりをしたい', 'Build soil without<br>relying on chemical fertilizers' ) ); ?></p>
			</div>
			<div class="lp-trouble">
				<div class="lp-trouble__mark">?</div>
				<p><?php echo wp_kses_post( lp_t( '環境にやさしい持続可能な<br>農業に取り組みたい', 'Practice sustainable<br>and eco-friendly agriculture' ) ); ?></p>
			</div>
		</div>
		<p class="lp-troubles__arrow">▼ <?php echo esc_html( lp_t( '再生計画の製品が解決します', 'Saisei Keikaku products solve them' ) ); ?> ▼</p>
	</div>
</section>

<?php /* ========== Products ========== */ ?>
<section class="lp-section lp-section--soft" id="products">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">PRODUCTS</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '2つの製品で、農業の課題を解決', 'Solving agricultural challenges with two products' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '独自の効果と使いやすさを追求した、環境配慮型の農業資材です。', 'Eco-conscious farm inputs designed for distinctive effectiveness and ease of use.' ) ); ?></p>
		</div>
		<div class="lp-products">

			<article class="lp-product">
				<?php
				$img_pg = $lp_img . '/lp-pure-green.png';
				if ( lp_asset_exists( 'images/lp/lp-pure-green.png' ) ) : ?>
					<img class="lp-product__img" src="<?php echo esc_url( $img_pg ); ?>" alt="<?php echo esc_attr( lp_t( '植物活性液ピュアグリン', 'Pure Green plant activator' ) ); ?>" loading="lazy" width="1280" height="720">
				<?php else : ?>
					<div class="lp-product__img-ph"><b><?php echo esc_html( lp_t( 'ピュアグリン', 'Pure Green' ) ); ?></b><span>Pure Green</span></div>
				<?php endif; ?>
				<div class="lp-product__body">
					<span class="lp-product__no">PRODUCT 01</span>
					<h3><?php echo esc_html( lp_t( '植物活性液', 'Plant Activator' ) ); ?></h3>
					<div class="lp-product__name"><?php echo esc_html( lp_t( 'ピュアグリン（Pure Green）', 'Pure Green' ) ); ?></div>
					<p><?php echo esc_html( lp_t(
						'野菜の甘みを引き出す、健康と環境に優しい植物活性液です。苦味・エグ味の元となる硝酸態窒素を低減し、野菜本来の甘みと味を引き立てます。葉に吹きかけるだけの手軽さです。',
						'A plant activator that draws out the natural sweetness of vegetables — gentle on people and the environment. Reduces nitrate nitrogen (the source of bitterness) so true flavor can come through. Just spray on the leaves.'
					) ); ?></p>
					<ul>
						<li><?php echo esc_html( lp_t( '野菜本来の甘み・味を引き立てる', 'Brings out natural sweetness and flavor' ) ); ?></li>
						<li><?php echo esc_html( lp_t( '葉のpHを保ち防虫効果も期待できる', 'Maintains leaf pH, offering pest-deterrent effects' ) ); ?></li>
						<li><?php echo esc_html( lp_t( '食品由来の天然植物成分で安全・安心', 'Made from food-derived natural plant ingredients' ) ); ?></li>
					</ul>
					<a href="<?php echo esc_url( lp_page_url( 'pure-green' ) ); ?>" class="lp-product__link"><?php echo esc_html( lp_t( '詳しく見る ›', 'Read more ›' ) ); ?></a>
				</div>
			</article>

			<article class="lp-product">
				<?php
				$img_ob = $lp_img . '/lp-organic-brown.png';
				if ( lp_asset_exists( 'images/lp/lp-organic-brown.png' ) ) : ?>
					<img class="lp-product__img" src="<?php echo esc_url( $img_ob ); ?>" alt="<?php echo esc_attr( lp_t( 'オーガニックピュアブラウン', 'Organic Pure Brown' ) ); ?>" loading="lazy" width="1280" height="720">
				<?php else : ?>
					<div class="lp-product__img-ph"><b><?php echo wp_kses_post( lp_t( 'オーガニック<br>ピュアブラウン', 'Organic<br>Pure Brown' ) ); ?></b><span>Organic Pure Brown</span></div>
				<?php endif; ?>
				<div class="lp-product__body">
					<span class="lp-product__no">PRODUCT 02</span>
					<h3><?php echo esc_html( lp_t( '植物性有機肥料', 'Plant-based Fertilizer' ) ); ?></h3>
					<div class="lp-product__name"><?php echo esc_html( lp_t( 'オーガニックピュアブラウン', 'Organic Pure Brown' ) ); ?></div>
					<p><?php echo esc_html( lp_t(
						'サトウキビ由来の原料を使用した100％植物性の有機肥料です。砂糖の製造工程で生まれる残渣を活用し、豊富な栄養素で土壌微生物を活性化させます。2021年4月よりAmazonでも販売中です。',
						'A 100% plant-based organic fertilizer made from sugarcane. It activates soil microorganisms with the nutrients in the residues of sugar production. Available on Amazon since April 2021.'
					) ); ?></p>
					<ul>
						<li><?php echo esc_html( lp_t( '100％植物性で土壌との親和性が高い', '100% plant-based, highly compatible with soil' ) ); ?></li>
						<li><?php echo esc_html( lp_t( '匂いが少なく室内・ベランダでも使える', 'Low odor — usable indoors and on balconies' ) ); ?></li>
						<li><?php echo esc_html( lp_t( '有機JAS認定資材登録など各種認証を取得', 'Organic JAS registered and otherwise certified' ) ); ?></li>
					</ul>
					<a href="<?php echo esc_url( lp_page_url( 'organic-brown' ) ); ?>" class="lp-product__link"><?php echo esc_html( lp_t( '詳しく見る ›', 'Read more ›' ) ); ?></a>
				</div>
			</article>

		</div>
	</div>
</section>

<?php /* ========== Why us ========== */ ?>
<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">WHY US</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '再生計画の製品が選ばれる理由', 'Why our products are chosen' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '「持続可能」と「循環型」を信念に、農業と環境の両立を追求しています。', 'Guided by "sustainable" and "cyclical", we pursue agriculture and environment in balance.' ) ); ?></p>
		</div>
		<div class="lp-reasons">
			<div class="lp-reason">
				<div class="lp-reason__num">1</div>
				<div>
					<h3><?php echo esc_html( lp_t( '独自の効果を持った製品', 'Distinctive effectiveness' ) ); ?></h3>
					<p><?php echo esc_html( lp_t( '他にはない独自技術と原材料を使用した製品です。既存の農業資材では解決できなかった課題に応える、革新的なアプローチで開発しています。', 'Built on unique technologies and ingredients, our products take an innovative approach to challenges that conventional inputs could not solve.' ) ); ?></p>
				</div>
			</div>
			<div class="lp-reason">
				<div class="lp-reason__num">2</div>
				<div>
					<h3><?php echo esc_html( lp_t( '驚くほど簡単な利用', 'Remarkably easy to use' ) ); ?></h3>
					<p><?php echo esc_html( lp_t( '利用に特別な技能や注意を必要とせず、誰でも簡単に使えます。農業経験の少ない方から熟練農家まで、手軽に導入いただけます。', 'No special skills or precautions required — anyone can use them. From beginners to seasoned farmers, our products integrate easily into daily work.' ) ); ?></p>
				</div>
			</div>
			<div class="lp-reason">
				<div class="lp-reason__num">3</div>
				<div>
					<h3><?php echo esc_html( lp_t( '環境に配慮した素材', 'Eco-conscious materials' ) ); ?></h3>
					<p><?php echo esc_html( lp_t( '長期利用と再利用をモットーに、環境への負荷を最小限に抑えた原材料を厳選しています。食の安全と農業の持続可能性を両立します。', 'With long-term use and reuse as our motto, we carefully select materials that minimize environmental load — for both food safety and agricultural sustainability.' ) ); ?></p>
				</div>
			</div>
			<div class="lp-reason">
				<div class="lp-reason__num">4</div>
				<div>
					<h3><?php echo esc_html( lp_t( 'SDGsへの積極的な取り組み', 'An active commitment to the SDGs' ) ); ?></h3>
					<p><?php echo esc_html( lp_t(
						'持続可能な農業を通じて、飢餓をゼロに（目標2）、健康と福祉（目標3）、安全な水（目標6）、陸の豊かさ（目標15）などの達成に貢献しています。',
						'Through sustainable agriculture we contribute to Goals 2 (Zero Hunger), 3 (Good Health and Well-being), 6 (Clean Water) and 15 (Life on Land).'
					) ); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>

<?php /* ========== Philosophy ========== */ ?>
<section class="lp-section lp-philosophy" id="philosophy">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">PHILOSOPHY</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '企業理念', 'Our Philosophy' ) ); ?></h2>
			<p class="lp-lead"><?php echo wp_kses_post( lp_t( '「持続可能」と「循環型」がキーワード。<br>環境と農業の未来を見据えた製品づくりに取り組みます。', '"Sustainable" and "cyclical" are our keywords.<br>We build products with the future of both environment and agriculture in mind.' ) ); ?></p>
		</div>

		<div class="lp-mission">
			<span class="lp-block__label"><?php echo esc_html( lp_t( '経営理念 ─ MISSION', 'MISSION' ) ); ?></span>
			<p class="lp-mission__text"><?php echo wp_kses_post( lp_t(
				'「持続可能」と「循環型」をキーワードに、<br>環境に配慮した農業資材を通じて<br>食の安全と農業の未来に貢献する。',
				'Guided by "sustainable" and "cyclical",<br>we contribute to food safety and the future of agriculture<br>through eco-conscious farm inputs.'
			) ); ?></p>
		</div>

		<div class="lp-vision">
			<span class="lp-block__label"><?php echo esc_html( lp_t( 'VISION ─ 私たちが目指す姿', 'VISION' ) ); ?></span>
			<p><?php echo esc_html( lp_t( '農業と環境が共存する、持続可能な社会の実現へ。', 'Toward a sustainable society where agriculture and environment coexist.' ) ); ?></p>
		</div>

		<div class="lp-value">
			<span class="lp-block__label"><?php echo esc_html( lp_t( 'VALUE ─ 大切にする価値観', 'VALUES' ) ); ?></span>
			<div class="lp-values">
				<div class="lp-value-card"><b><?php echo esc_html( lp_t( '持続可能性', 'Sustainability' ) ); ?></b><p><?php echo esc_html( lp_t( '次世代へ豊かな農業環境を引き継ぎます。', 'We carry a rich agricultural environment to the next generation.' ) ); ?></p></div>
				<div class="lp-value-card"><b><?php echo esc_html( lp_t( '循環型', 'Circularity' ) ); ?></b><p><?php echo esc_html( lp_t( '自然の循環を活かした農業資材を追求します。', 'We pursue farm inputs that work with natural cycles.' ) ); ?></p></div>
				<div class="lp-value-card"><b><?php echo esc_html( lp_t( '安全・安心', 'Safety & Trust' ) ); ?></b><p><?php echo esc_html( lp_t( '食品由来の原材料で人と環境に優しい製品を提供します。', 'Food-derived ingredients gentle to people and environment.' ) ); ?></p></div>
			</div>
		</div>
	</div>
</section>

<?php /* ========== How to ========== */ ?>
<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">HOW TO</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( 'ご購入・ご利用の流れ', 'How to purchase and use' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( 'お問い合わせからご購入まで、丁寧にサポートします。', 'We support you carefully from first inquiry through purchase.' ) ); ?></p>
		</div>
		<div class="lp-flow">
			<div class="lp-flow__step">
				<b>STEP 1</b>
				<h4><?php echo esc_html( lp_t( '製品の確認', 'Review the product' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( '各製品ページをご覧いただき、用途・効果をご確認ください。', 'Visit each product page to confirm purpose and effects.' ) ); ?></p>
			</div>
			<div class="lp-flow__step">
				<b>STEP 2</b>
				<h4><?php echo esc_html( lp_t( 'お問い合わせ', 'Contact us' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( 'ご不明な点はフォームまたはお電話でお気軽にご相談ください。', 'For any questions, reach out via the form or by phone.' ) ); ?></p>
			</div>
			<div class="lp-flow__step">
				<b>STEP 3</b>
				<h4><?php echo esc_html( lp_t( 'ご購入', 'Purchase' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( 'Amazon等のオンラインショップ、または直接お申し込みいただけます。', 'Order through Amazon or other online stores, or contact us directly.' ) ); ?></p>
			</div>
			<div class="lp-flow__step">
				<b>STEP 4</b>
				<h4><?php echo esc_html( lp_t( 'ご利用開始', 'Start using' ) ); ?></h4>
				<p><?php echo esc_html( lp_t( '特別な技能不要で、すぐにお使いいただけます。', 'No special skill required — you can start using right away.' ) ); ?></p>
			</div>
		</div>
	</div>
</section>

<?php /* ========== Company ========== */ ?>
<section class="lp-section lp-section--soft" id="company">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">COMPANY</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '会社概要', 'Company Profile' ) ); ?></h2>
		</div>
		<div class="lp-company">
			<table>
				<tbody>
					<tr><th><?php echo esc_html( lp_t( '会社名', 'Company name' ) ); ?></th><td><?php echo esc_html( lp_company_name() ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '代表者', 'Representative' ) ); ?></th><td><?php echo esc_html( lp_cf( 'ceo' ) ); ?></td></tr>
					<?php if ( ! empty( $cfg['capital'] ) ) : ?>
					<tr><th><?php echo esc_html( lp_t( '資本金', 'Capital' ) ); ?></th><td><?php echo esc_html( lp_cf( 'capital' ) ); ?></td></tr>
					<?php endif; ?>
					<tr><th><?php echo esc_html( lp_t( '所在地', 'Address' ) ); ?></th><td><?php echo esc_html( lp_cf( 'address' ) ); ?></td></tr>
					<?php if ( $cfg['tel'] ) : ?>
					<tr><th><?php echo esc_html( lp_t( '電話番号', 'Tel' ) ); ?></th><td><?php if ( $cfg['tel_link'] ) : ?><a href="tel:<?php echo esc_attr( $cfg['tel_link'] ); ?>"><?php endif; ?><?php echo esc_html( $cfg['tel'] ); ?><?php if ( $cfg['tel_link'] ) : ?></a><?php endif; ?></td></tr>
					<?php endif; ?>
					<?php if ( $cfg['fax'] ) : ?>
					<tr><th>FAX</th><td><?php echo esc_html( $cfg['fax'] ); ?></td></tr>
					<?php endif; ?>
					<tr><th><?php echo esc_html( lp_t( 'メール', 'Email' ) ); ?></th><td><a href="mailto:<?php echo esc_attr( $cfg['mail'] ); ?>"><?php echo esc_html( $cfg['mail'] ); ?></a></td></tr>
					<tr><th><?php echo esc_html( lp_t( '事業内容', 'Business' ) ); ?></th><td><?php echo esc_html( lp_t( '植物活性液ピュアグリンの開発・販売／植物性有機肥料オーガニックピュアブラウンの製造・販売', 'Development and sales of Pure Green / Manufacture and sales of Organic Pure Brown' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( 'キーワード', 'Keywords' ) ); ?></th><td><?php echo esc_html( lp_t( '持続可能・循環型農業・環境配慮・SDGs', 'Sustainable · Cyclical · Eco-conscious · SDGs' ) ); ?></td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<?php lp_cta(); ?>
<?php lp_footer(); ?>
