<?php
/**
 * Template Name: 植物性有機肥料（再生計画）
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';
$cfg    = lp_cfg();
$amazon = 'https://www.amazon.co.jp/s?k=' . rawurlencode( 'オーガニックピュアブラウン' );

lp_head(
	lp_t( '植物性有機肥料 オーガニックピュアブラウン', 'Organic Pure Brown — Plant-based Fertilizer' ),
	lp_t(
		'サトウキビ由来の原料を使用した100％植物性有機肥料「オーガニックピュアブラウン」。匂いが少なく室内・ベランダでも使え、有機JAS認定資材登録など各種認証を取得。Amazonでも購入可能。',
		'Organic Pure Brown — a 100% plant-based organic fertilizer made from sugarcane. Low odor, usable indoors and on balconies, with multiple certifications including Organic JAS. Available on Amazon.'
	)
);
lp_header( 'brown' );
lp_pagehead( 'ORGANIC FERTILIZER', lp_t( '植物性有機肥料 オーガニックピュアブラウン', 'Organic Pure Brown — Plant-based Fertilizer' ) );
?>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-product-detail">
			<div class="lp-product-detail__img">
				<?php if ( lp_asset_exists( 'images/lp/lp-organic-brown.png' ) ) : ?>
					<img src="<?php echo esc_url( lp_asset_url( 'images/lp/lp-organic-brown.png' ) ); ?>" alt="<?php echo esc_attr( lp_t( '植物性有機肥料オーガニックピュアブラウン', 'Organic Pure Brown plant-based fertilizer' ) ); ?>" loading="lazy" width="1280" height="960">
				<?php else : ?>
					<div class="lp-product-detail__img-ph"><b><?php echo wp_kses_post( lp_t( 'オーガニック<br>ピュアブラウン', 'Organic<br>Pure Brown' ) ); ?></b><span>Organic Pure Brown</span></div>
				<?php endif; ?>
			</div>
			<div class="lp-product-detail__body">
				<span class="lp-product-detail__tag"><?php echo esc_html( lp_t( '100％植物性有機肥料', '100% Plant-based Fertilizer' ) ); ?></span>
				<h3><?php echo wp_kses_post( lp_t( '植物性有機肥料<br>オーガニックピュアブラウン', 'Plant-based Fertilizer<br>Organic Pure Brown' ) ); ?></h3>
				<p><?php echo esc_html( lp_t(
					'フィリピン共和国から輸入したサトウキビ由来の原料を使用した、100％植物性の有機肥料です。砂糖の製造工程で生まれる残渣のみを活用しており、豊富な栄養素を含んでいます。',
					'A 100% plant-based organic fertilizer made from sugarcane-derived material imported from the Republic of the Philippines. It uses only the residues from sugar production, and is rich in nutrients.'
				) ); ?></p>
				<p><?php echo esc_html( lp_t(
					'「持続可能」と「循環型」を理念に、土壌との親和性が高く、土壌微生物を活性化させながら作物を育てます。匂いが少なく、室内やベランダでもお使いいただけます。2021年4月よりAmazonでも購入いただけます。',
					'Highly compatible with soil and activating beneficial soil microorganisms, it nurtures crops under our "sustainable" and "cyclical" philosophy. Low odor — usable indoors and on balconies. Available on Amazon since April 2021.'
				) ); ?></p>
				<a href="<?php echo esc_url( $amazon ); ?>" target="_blank" rel="noopener noreferrer" class="lp-amazon">&#128722; <?php echo esc_html( lp_t( 'Amazonで購入する', 'Buy on Amazon' ) ); ?></a>
				<span class="lp-product-detail__label">FEATURES</span>
				<ul style="list-style:none;padding:0;">
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( 'サトウキビ由来・100％植物性で土壌との親和性が高い', 'Sugarcane-derived, 100% plant-based, highly soil-compatible.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '動物性肥料に比べ農薬汚染のリスクが少ない', 'Lower pesticide-contamination risk vs. animal-derived fertilizers.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '砂糖製造の残渣を活用した、半永久的に供給できる循環型資源', 'Virtually inexhaustible cyclical resource from sugar-production residues.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '長期発酵により殺菌され、匂いが少なく室内・ベランダでも使える', 'Long fermentation sterilizes the material — low odor, usable indoors.' ) ); ?></li>
					<li style="padding:7px 0 7px 26px;position:relative;"><span style="position:absolute;left:0;color:var(--green);font-weight:900;">✓</span><?php echo esc_html( lp_t( '栄養をゆるやかに供給し、土壌微生物を活性化させる', 'Releases nutrients gradually, activating soil microorganisms.' ) ); ?></li>
				</ul>
			</div>
		</div>
	</div>
</section>

<section class="lp-section lp-section--soft">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">FEATURES</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( 'オーガニックピュアブラウンの特長', 'Features of Organic Pure Brown' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( 'サトウキビ由来の循環型資源で、土と作物の力を引き出します。', 'A circular sugarcane-derived resource that draws out the power of soil and crop.' ) ); ?></p>
		</div>
		<div class="lp-reasons">
			<div class="lp-reason">
				<div class="lp-reason__num">1</div>
				<div>
					<h3><?php echo esc_html( lp_t( 'サトウキビ由来の循環型資源', 'Sugarcane-based circular resource' ) ); ?></h3>
					<p><?php echo esc_html( lp_t( '砂糖の製造過程で生まれる残渣のみを原料に利用。使い終えれば土に還り、再びサトウキビを育てる、半永久的な循環をかたちにした肥料です。', 'Built only from sugar-production residues. Spent fertilizer returns to the soil to grow sugarcane again — embodying a virtually inexhaustible cycle.' ) ); ?></p>
				</div>
			</div>
			<div class="lp-reason">
				<div class="lp-reason__num">2</div>
				<div>
					<h3><?php echo esc_html( lp_t( '100％植物性で安心', 'Reassuringly 100% plant-based' ) ); ?></h3>
					<p><?php echo esc_html( lp_t( '動物性肥料で懸念される農薬汚染のリスクがなく、土壌との親和性が高い植物性原料のみを使用。人にも土にもやさしい有機肥料です。', 'No pesticide-contamination concern that comes with animal-derived fertilizers — only plant-based, soil-compatible ingredients. Gentle on people and soil.' ) ); ?></p>
				</div>
			</div>
			<div class="lp-reason">
				<div class="lp-reason__num">3</div>
				<div>
					<h3><?php echo esc_html( lp_t( '匂いが少なく扱いやすい', 'Low odor, easy to handle' ) ); ?></h3>
					<p><?php echo esc_html( lp_t( '長期発酵によって殺菌され匂いが抑えられているため、室内やベランダでのプランター栽培にも安心してお使いいただけます。', 'Long fermentation sterilizes and suppresses odor, so it can be used confidently indoors and on balconies in planter cultivation.' ) ); ?></p>
				</div>
			</div>
			<div class="lp-reason">
				<div class="lp-reason__num">4</div>
				<div>
					<h3><?php echo esc_html( lp_t( '土壌微生物を活性化', 'Activates soil microorganisms' ) ); ?></h3>
					<p><?php echo esc_html( lp_t( '栄養をゆるやかに供給することで土壌微生物のはたらきを助け、作物が育ち続けられる健全な土づくりをサポートします。', 'Gradual nutrient release supports the work of soil microorganisms, helping build healthy soil where crops keep growing.' ) ); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">CERTIFICATIONS</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '取得している認証', 'Certifications obtained' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '第三者機関による各種認証を取得した、信頼の有機肥料です。', 'A trusted organic fertilizer certified by multiple independent third-party organizations.' ) ); ?></p>
		</div>
		<div class="lp-company" style="margin-top:34px;">
			<table>
				<tbody>
					<tr><th><?php echo esc_html( lp_t( '有機JAS', 'Organic JAS' ) ); ?></th><td><?php echo esc_html( lp_t( '有機JAS認定資材として登録されています。', 'Registered as an Organic JAS-certified input material.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '有機認証', 'Organic certification' ) ); ?></th><td><?php echo esc_html( lp_t( '有機認証センターによる有機認証を取得しています。', 'Certified organic by the Organic Certification Center.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( 'ハラール認証', 'Halal certification' ) ); ?></th><td><?php echo esc_html( lp_t( 'フィリピン共和国においてハラール認証を取得しています。', 'Halal-certified in the Republic of the Philippines.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '製品登録', 'Product registration' ) ); ?></th><td><?php echo esc_html( lp_t( 'フィリピン共和国農業省による製品登録を受けています。', 'Registered as a product by the Department of Agriculture of the Philippines.' ) ); ?></td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<section class="lp-section lp-section--soft">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">HOW TO USE</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '使用方法・使用上の目安', 'How to apply — recommended amounts' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '作物や土壌の状態に合わせてお使いください。', 'Adjust to suit your crops and soil conditions.' ) ); ?></p>
		</div>
		<div class="lp-company" style="margin-top:34px;">
			<table>
				<tbody>
					<tr><th><?php echo esc_html( lp_t( '施肥のタイミング', 'Timing' ) ); ?></th><td><?php echo esc_html( lp_t( '栽培開始の2〜3週間前を目安に施肥してください。', 'Apply 2–3 weeks before cultivation begins.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '使用量（大規模）', 'Dosage (large-scale)' ) ); ?></th><td><?php echo esc_html( lp_t( '1ヘクタールあたり 元肥2,000kg・追肥1,000kg を目安にご使用ください。', 'Per hectare: 2,000 kg base / 1,000 kg supplemental.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '使用量（小規模）', 'Dosage (small-scale)' ) ); ?></th><td><?php echo esc_html( lp_t( 'プランター（65cm／約12L）あたり 元肥100g・追肥20g を目安にご使用ください。', 'Per 65 cm planter (≈ 12 L): 100 g base / 20 g supplemental.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '対応作物', 'Crops' ) ); ?></th><td><?php echo esc_html( lp_t( '野菜類・果菜類・葉菜類・根菜類など幅広い作物に対応しています。', 'Suitable for a wide range of crops — vegetables, fruit-bearing, leafy, root.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '保管方法', 'Storage' ) ); ?></th><td><?php echo esc_html( lp_t( '直射日光を避け、冷暗所で保管してください。開封後はなるべく早くご使用ください。', 'Store in a cool, dark place away from direct sunlight. After opening, use as soon as possible.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( 'ご購入方法', 'Where to buy' ) ); ?></th><td><?php echo esc_html( lp_t( 'Amazonオンラインショップ、または当社へのお問い合わせよりご購入いただけます。', 'Available on Amazon, or by direct inquiry to us.' ) ); ?></td></tr>
				</tbody>
			</table>
		</div>
		<div class="lp-quote" style="margin-top:28px;">
			<p><?php echo esc_html( lp_t( '詳しい使用量・注意事項については、製品に同梱の説明書をご確認いただくか、お問い合わせフォームよりご連絡ください。', 'For detailed dosage and precautions, please refer to the instructions included with the product, or contact us via the inquiry form.' ) ); ?></p>
		</div>
	</div>
</section>

<section class="lp-section">
	<div class="lp-wrap lp-center">
		<span class="lp-eyebrow">PURCHASE</span>
		<h2 class="lp-h2"><?php echo esc_html( lp_t( 'ご購入はこちらから', 'Where to purchase' ) ); ?></h2>
		<p class="lp-lead" style="margin:0 auto 34px;"><?php echo wp_kses_post( lp_t( 'Amazonでお手軽にご購入いただけます。<br>ご不明な点は当社にお問い合わせください。', 'Easily purchase on Amazon.<br>For any questions, please contact us.' ) ); ?></p>
		<div style="display:flex;flex-wrap:wrap;gap:16px;justify-content:center;">
			<a href="<?php echo esc_url( $amazon ); ?>" target="_blank" rel="noopener noreferrer" class="lp-amazon" style="font-size:1rem;padding:14px 28px;">&#128722; <?php echo esc_html( lp_t( 'Amazonで購入する', 'Buy on Amazon' ) ); ?></a>
			<a href="<?php echo esc_url( lp_contact_url() ); ?>" class="lp-btn lp-btn--ghost lp-btn--lg"><?php echo esc_html( lp_t( 'お問い合わせはこちら', 'Contact us' ) ); ?></a>
		</div>
	</div>
</section>

<?php lp_cta(); ?>
<?php lp_footer(); ?>
