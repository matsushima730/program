<?php
/**
 * Template Name: お問い合わせ（再生計画）
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';
$cfg = lp_cfg();

/* ===== フォーム送信処理 ===== */
$lp_msg = '';
$lp_ok  = false;
$lp_val = array(
	'name'  => '',
	'email' => '',
	'title' => '',
	'body'  => '',
);

if ( 'POST' === $_SERVER['REQUEST_METHOD']
	&& isset( $_POST['lp_contact_nonce'] )
	&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lp_contact_nonce'] ) ), 'lp_contact' ) ) {

	if ( ! empty( $_POST['lp_website'] ) ) {
		$lp_ok  = true;
		$lp_msg = lp_t( 'お問い合わせを送信しました。ありがとうございました。', 'Your inquiry has been sent. Thank you.' );
	} else {
		$lp_val['name']  = sanitize_text_field( wp_unslash( $_POST['lp_name'] ?? '' ) );
		$lp_val['email'] = sanitize_email( wp_unslash( $_POST['lp_email'] ?? '' ) );
		$lp_val['title'] = sanitize_text_field( wp_unslash( $_POST['lp_title'] ?? '' ) );
		$lp_val['body']  = sanitize_textarea_field( wp_unslash( $_POST['lp_body'] ?? '' ) );

		if ( '' === $lp_val['name'] || '' === $lp_val['email'] || '' === $lp_val['title'] || '' === $lp_val['body'] ) {
			$lp_msg = lp_t( 'すべての項目をご入力ください。', 'Please fill in all required fields.' );
		} elseif ( ! is_email( $lp_val['email'] ) ) {
			$lp_msg = lp_t( 'メールアドレスの形式が正しくありません。', 'The email address format is invalid.' );
		} else {
			$to      = $cfg['mail'];
			$subject = lp_t( '【お問い合わせ】', '[Inquiry] ' ) . $lp_val['title'];
			$message = lp_t(
				"Webサイトのお問い合わせフォームより送信されました。\n",
				"Sent from the website contact form.\n"
			) . "\n"
				. '──────────────────' . "\n"
				. lp_t( 'お名前', 'Name' )  . ' : ' . $lp_val['name']  . "\n"
				. lp_t( 'メール', 'Email' )  . ' : ' . $lp_val['email'] . "\n"
				. lp_t( '件名',   'Subject' ) . ' : ' . $lp_val['title'] . "\n"
				. '──────────────────' . "\n\n"
				. $lp_val['body'] . "\n";
			$headers = array(
				'Content-Type: text/plain; charset=UTF-8',
				'Reply-To: ' . $lp_val['name'] . ' <' . $lp_val['email'] . '>',
			);

			if ( wp_mail( $to, $subject, $message, $headers ) ) {
				$lp_ok  = true;
				$lp_msg = lp_t( 'お問い合わせを送信しました。担当者より折り返しご連絡いたします。', 'Your inquiry has been sent. We will get back to you shortly.' );
				$lp_val = array( 'name' => '', 'email' => '', 'title' => '', 'body' => '' );
			} else {
				$lp_msg = lp_t(
					'送信に失敗しました。お手数ですがメール（' . $cfg['mail'] . '）にて直接ご連絡ください。',
					'Sending failed. Please contact us directly by email (' . $cfg['mail'] . ').'
				);
			}
		}
	}
}

lp_head(
	lp_t( 'お問い合わせ', 'Contact' ),
	lp_t(
		'有限会社再生計画へのお問い合わせ。植物活性液ピュアグリン・植物性有機肥料オーガニックピュアブラウンに関するご購入・ご相談を承ります。',
		'Contact Saisei Keikaku Co., Ltd. — for purchases and inquiries about Pure Green plant activator and Organic Pure Brown plant-based fertilizer.'
	)
);
lp_header( 'contact' );
lp_pagehead( 'CONTACT', lp_t( 'お問い合わせ', 'Contact' ) );
?>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">CONTACT FORM</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( 'お問い合わせフォーム', 'Contact Form' ) ); ?></h2>
			<p class="lp-lead">
				<?php echo wp_kses_post( lp_t(
					'製品のご購入・使用方法・農地への適用・その他ご不明な点はお気軽にご連絡ください。<br>下記フォームに必要事項をご入力のうえ送信してください。',
					'Feel free to reach out about product purchases, usage, applications to your farmland, and any other questions.<br>Please fill in the form below and submit.'
				) ); ?>
			</p>
		</div>

		<div class="lp-form">
			<?php if ( '' !== $lp_msg ) : ?>
				<p class="lp-alert <?php echo $lp_ok ? 'lp-alert--ok' : 'lp-alert--ng'; ?>">
					<?php echo esc_html( $lp_msg ); ?>
				</p>
			<?php endif; ?>

			<?php if ( ! $lp_ok ) : ?>
			<form method="post" action="<?php echo esc_url( lp_contact_url() ); ?>">
				<?php wp_nonce_field( 'lp_contact', 'lp_contact_nonce' ); ?>

				<div class="lp-field">
					<label for="lp-name"><?php echo esc_html( lp_t( 'お名前', 'Name' ) ); ?><span class="req"><?php echo esc_html( lp_t( '必須', 'Required' ) ); ?></span></label>
					<input type="text" id="lp-name" name="lp_name" value="<?php echo esc_attr( $lp_val['name'] ); ?>" required>
				</div>
				<div class="lp-field">
					<label for="lp-email"><?php echo esc_html( lp_t( 'メールアドレス', 'Email address' ) ); ?><span class="req"><?php echo esc_html( lp_t( '必須', 'Required' ) ); ?></span></label>
					<input type="email" id="lp-email" name="lp_email" value="<?php echo esc_attr( $lp_val['email'] ); ?>" required>
				</div>
				<div class="lp-field">
					<label for="lp-title"><?php echo esc_html( lp_t( '件名', 'Subject' ) ); ?><span class="req"><?php echo esc_html( lp_t( '必須', 'Required' ) ); ?></span></label>
					<input type="text" id="lp-title" name="lp_title" value="<?php echo esc_attr( $lp_val['title'] ); ?>" required>
				</div>
				<div class="lp-field">
					<label for="lp-body"><?php echo esc_html( lp_t( 'お問い合わせ内容', 'Your message' ) ); ?><span class="req"><?php echo esc_html( lp_t( '必須', 'Required' ) ); ?></span></label>
					<textarea id="lp-body" name="lp_body" required><?php echo esc_textarea( $lp_val['body'] ); ?></textarea>
				</div>

				<div class="lp-hp" aria-hidden="true">
					<label for="lp-website"><?php echo esc_html( lp_t( 'このフィールドは空のままにしてください', 'Leave this field empty' ) ); ?></label>
					<input type="text" id="lp-website" name="lp_website" tabindex="-1" autocomplete="off">
				</div>

				<div class="lp-form__submit">
					<button type="submit" class="lp-btn lp-btn--primary lp-btn--lg"><?php echo esc_html( lp_t( 'この内容で送信する', 'Send' ) ); ?></button>
				</div>
				<p class="lp-form__note">
					<?php echo esc_html( lp_t( 'ご入力いただいた個人情報は、お問い合わせへの対応のみに利用します。', 'Any personal information you provide will be used only to respond to your inquiry.' ) ); ?><br>
					<?php
					if ( 'en' === lp_lang() ) {
						printf(
							'See our <a href="%s">Privacy Policy</a> for details.',
							esc_url( lp_page_url( $cfg['nav']['privacy']['path'] ) )
						);
					} else {
						printf(
							'詳しくは<a href="%s">プライバシーポリシー</a>をご覧ください。',
							esc_url( lp_page_url( $cfg['nav']['privacy']['path'] ) )
						);
					}
					?>
				</p>
			</form>
			<?php endif; ?>

			<div class="lp-contactinfo">
				<b><?php echo esc_html( lp_t( 'その他のお問い合わせ方法', 'Other ways to reach us' ) ); ?></b><br>
				<?php if ( $cfg['tel'] ) : ?>
				TEL：<?php if ( $cfg['tel_link'] ) : ?><a href="tel:<?php echo esc_attr( $cfg['tel_link'] ); ?>"><?php endif; ?><?php echo esc_html( $cfg['tel'] ); ?><?php if ( $cfg['tel_link'] ) : ?></a><?php endif; ?><?php if ( $cfg['fax'] ) { echo '　/　FAX：' . esc_html( $cfg['fax'] ); } ?><br>
				<?php endif; ?>
				<?php echo esc_html( lp_t( 'メール', 'Email' ) ); ?>：<a href="mailto:<?php echo esc_attr( $cfg['mail'] ); ?>"><?php echo esc_html( $cfg['mail'] ); ?></a><br>
				<?php if ( $cfg['address'] ) : ?>
				<?php echo esc_html( lp_t( '所在地', 'Address' ) ); ?>：<?php echo esc_html( lp_cf( 'address' ) ); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>

<?php lp_footer(); ?>
