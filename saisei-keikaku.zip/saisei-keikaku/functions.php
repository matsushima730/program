<?php
/**
 * Saisei Keikaku テーマ functions
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'saisei_setup' ) ) {
	function saisei_setup() {
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support(
			'html5',
			array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
		);
		load_theme_textdomain( 'saisei-keikaku', get_template_directory() . '/languages' );
	}
}
add_action( 'after_setup_theme', 'saisei_setup' );

/*
 * 注意: title-tag のテーマサポートは意図的に追加していません。
 * 各テンプレートが lp_head() 内で独自に <title> を出力するため、
 * 追加すると <title> が二重出力されます。
 */

/**
 * テーマ有効化時に、サイトに必要な固定ページを自動作成する。
 * 既に同じスラッグのページが存在する場合は作成しません。
 * 各ページはスラッグに対応する page-{slug}.php テンプレートで自動表示されます。
 */
function saisei_create_default_pages() {
	$pages = array(
		'company-detail'  => '会社案内',
		'pure-green'      => '植物活性液',
		'organic-brown'   => '植物性有機肥料',
		'sdgs'            => 'SDGs',
		'contact-us'      => 'お問い合わせ',
		'privacypolicy'   => 'プライバシーポリシー',
	);
	foreach ( $pages as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post(
				array(
					'post_title'     => $title,
					'post_name'      => $slug,
					'post_status'    => 'publish',
					'post_type'      => 'page',
					'post_content'   => '',
					'comment_status' => 'closed',
					'ping_status'    => 'closed',
				)
			);
		}
	}
}
add_action( 'after_switch_theme', 'saisei_create_default_pages' );
// 管理画面アクセス時にも実行し、固定ページが欠けている場合は補完する（冪等）。
add_action( 'admin_init', 'saisei_create_default_pages' );
