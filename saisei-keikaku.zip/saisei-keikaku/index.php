<?php
/**
 * 汎用フォールバックテンプレート
 *
 * 専用テンプレート（front-page.php / page-{slug}.php）が無いリクエスト
 * （404・検索・アーカイブ・その他の固定ページ等）で使用されます。
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';

$qo_id        = get_queried_object_id();
$lp_obj_title = $qo_id ? get_the_title( $qo_id ) : '';
if ( is_404() ) {
	$lp_obj_title = lp_t( 'ページが見つかりません', 'Page Not Found' );
} elseif ( is_search() ) {
	$lp_obj_title = lp_t( '検索結果', 'Search Results' );
} elseif ( is_home() || is_archive() ) {
	$lp_obj_title = lp_t( 'お知らせ', 'News' );
}
if ( '' === $lp_obj_title ) {
	$lp_obj_title = lp_company_name();
}

lp_head( $lp_obj_title, get_bloginfo( 'description', 'display' ) );
lp_header();
lp_pagehead( '', $lp_obj_title );
?>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-prose">
			<?php
			if ( is_404() ) {
				echo '<p>' . esc_html( lp_t( 'お探しのページは見つかりませんでした。お手数ですが、メニューまたはホームからお探しください。', 'The page you are looking for could not be found. Please use the menu or return to the home page.' ) ) . '</p>';
				echo '<p><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( lp_t( 'ホームへ戻る', 'Back to Home' ) ) . '</a></p>';
			} elseif ( have_posts() ) {
				while ( have_posts() ) {
					the_post();
					if ( is_singular() ) {
						the_content();
					} else {
						echo '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
						the_excerpt();
					}
				}
			} else {
				echo '<p>' . esc_html( lp_t( '表示できるコンテンツがありません。', 'No content to display.' ) ) . '</p>';
			}
			?>
		</div>
	</div>
</section>

<?php
lp_footer();
