<?php
/**
 * Template Name: SDGs（再生計画）
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';
$cfg = lp_cfg();

lp_head(
	lp_t( 'SDGsへの取り組み', 'Our SDGs commitments' ),
	lp_t(
		'有限会社再生計画のSDGsへの取り組み。持続可能な農業と環境配慮型の製品開発を通じて、持続可能な開発目標の達成に貢献します。',
		'Saisei Keikaku Co., Ltd.\'s commitment to the SDGs — contributing to the Sustainable Development Goals through sustainable agriculture and eco-conscious product development.'
	)
);
lp_header( 'sdgs' );
lp_pagehead( 'SDGs', lp_t( 'SDGsへの取り組み', 'Our SDGs commitments' ) );

$lp_goals = array(
	array(
		'no'    => 3,
		'title' => lp_t( 'すべての人に健康と福祉を', 'Good Health and Well-being' ),
		'text'  => lp_t(
			'作物に蓄積する硝酸態窒素を減らし、乳児を中心とした健康被害を減らすために、製品の開発・製造を通じて活動します。',
			'We develop and manufacture products that reduce nitrate nitrogen accumulating in crops, helping prevent health risks — especially for infants.'
		),
		'color' => '#4C9F38',
	),
	array(
		'no'    => 6,
		'title' => lp_t( '安全な水とトイレを世界中に', 'Clean Water and Sanitation' ),
		'text'  => lp_t(
			'化学肥料の利用による地下水の汚染を抑制し、水の安全性の向上に寄与します。',
			'By curbing groundwater contamination from chemical fertilizers, we contribute to safer water for all.'
		),
		'color' => '#26BDE2',
	),
	array(
		'no'    => 9,
		'title' => lp_t( '産業と技術革新の基盤をつくろう', 'Industry, Innovation and Infrastructure' ),
		'text'  => lp_t(
			'未利用資源の有効活用と独自製品の開発を通じて、持続可能な農業のための新たな基盤づくりに取り組みます。',
			'Through the effective use of unused resources and the development of distinctive products, we build new infrastructure for sustainable agriculture.'
		),
		'color' => '#FD6925',
	),
	array(
		'no'    => 12,
		'title' => lp_t( 'つくる責任 つかう責任', 'Responsible Consumption and Production' ),
		'text'  => lp_t(
			'サトウキビの残渣を肥料に変える循環型のものづくりを推進し、限りある資源を有効に活かす農業を提案します。',
			'By turning sugarcane residue into fertilizer, we promote circular production and propose agriculture that makes the most of limited resources.'
		),
		'color' => '#BF8B2E',
	),
	array(
		'no'    => 15,
		'title' => lp_t( '陸の豊かさも守ろう', 'Life on Land' ),
		'text'  => lp_t(
			'作物が生育し続けられる土壌づくりの促進に貢献し、豊かな農地を次世代へ引き継ぎます。',
			'We support soil-building practices that let crops thrive, passing on fertile farmland to the next generation.'
		),
		'color' => '#56C02B',
	),
);
?>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">SDGs DECLARATION</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( 'SDGs宣言', 'SDGs Declaration' ) ); ?></h2>
		</div>

		<div class="lp-sdgs-banner">
			<div class="lp-sdgs-banner__company">
				<?php $lp_logo_src = lp_company_logo_url(); ?>
				<?php if ( $lp_logo_src ) : ?>
					<img src="<?php echo esc_url( $lp_logo_src ); ?>" alt="<?php echo esc_attr( lp_company_name() ); ?>">
				<?php else : ?>
					<div style="font-weight:900;font-size:1.1rem;color:var(--green-dark);"><?php echo esc_html( lp_company_name() ); ?></div>
				<?php endif; ?>
			</div>
			<div class="lp-sdgs-banner__line" aria-hidden="true"></div>
			<div class="lp-sdgs-banner__sdgs">
				<?php $lp_sdgs_logo = lp_sdgs_asset( 'sdgs-logo.png' ); ?>
				<?php if ( $lp_sdgs_logo ) : ?>
					<img src="<?php echo esc_url( $lp_sdgs_logo ); ?>" alt="Sustainable Development Goals">
				<?php else : ?>
					<span class="lp-ph">SDGs</span>
				<?php endif; ?>
			</div>
		</div>

		<div class="lp-center" style="margin-top:30px;">
			<p class="lp-lead">
				<?php echo esc_html( lp_t(
					sprintf( '%sは、「持続可能」と「循環型」という経営理念のもと、植物活性液・植物性有機肥料の開発・販売を通じて、持続可能な開発目標（SDGs）の達成に貢献することを宣言します。私たちが特に注力するのは、次の4つの目標です。', lp_company_name() ),
					sprintf( '%s, guided by our management principles of "sustainable" and "cyclical", declares its commitment to advancing the Sustainable Development Goals (SDGs) through the development and sale of plant activator liquid and plant-based organic fertilizer. We focus on the following four goals.', lp_company_name() )
				) ); ?>
			</p>
		</div>

		<div class="lp-sdgs-icons">
			<?php
			foreach ( $lp_goals as $g ) {
				$nn  = sprintf( '%02d', $g['no'] );
				$url = lp_sdgs_asset( "sdg-{$nn}.png" );
				$alt = lp_t(
					'SDGs ' . $g['no'] . '：' . $g['title'],
					'SDG ' . $g['no'] . ' — ' . $g['title']
				);
				if ( $url ) {
					printf(
						'<img src="%s" alt="%s" width="128" height="128" loading="lazy">',
						esc_url( $url ),
						esc_attr( $alt )
					);
				} else {
					printf(
						'<span class="lp-ph" style="background:%s" role="img" aria-label="%s"><b>%d</b><span>%s</span></span>',
						esc_attr( $g['color'] ),
						esc_attr( $alt ),
						(int) $g['no'],
						esc_html( $g['title'] )
					);
				}
			}
			?>
		</div>

		<p class="lp-sdgs-note">
			<?php echo esc_html( lp_t(
				'当ウェブサイトの内容は国際連合によって承認されたものではなく、国際連合またはその加盟国の見解を反映するものではありません。',
				'The content of this website has not been approved by the United Nations and does not reflect the views of the United Nations or its Member States.'
			) ); ?><br>
			<a href="https://www.un.org/sustainabledevelopment/" target="_blank" rel="noopener noreferrer"><?php echo esc_html( lp_t( '国際連合 持続可能な開発目標（SDGs）について ›', 'About the UN Sustainable Development Goals ›' ) ); ?></a>
		</p>
	</div>
</section>

<section class="lp-section lp-section--soft">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">TARGET GOALS</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '事業を通じて貢献する4つの目標', 'Four goals we contribute to through our business' ) ); ?></h2>
			<p class="lp-lead"><?php echo esc_html( lp_t( '持続可能な農業資材の開発・普及という本業そのものが、SDGsの達成につながっています。', 'Our core business — developing and spreading sustainable farm inputs — is itself a contribution to the SDGs.' ) ); ?></p>
		</div>

		<div class="lp-reasons">
			<?php foreach ( $lp_goals as $g ) : ?>
			<div class="lp-reason">
				<div class="lp-reason__num" style="background:<?php echo esc_attr( $g['color'] ); ?>"><?php echo (int) $g['no']; ?></div>
				<div>
					<h3><?php echo esc_html( $g['title'] ); ?></h3>
					<p><?php echo esc_html( $g['text'] ); ?></p>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">POLICY</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '環境への基本姿勢', 'Our basic environmental stance' ) ); ?></h2>
		</div>
		<div class="lp-quote">
			<p>
				<?php echo esc_html( lp_t(
					'オーガニックピュアブラウンは、砂糖の製造過程で生まれるサトウキビの残渣を原料としています。使い終えた肥料は土に還り、ふたたびサトウキビを育てる──私たちはこうした資源の循環を事業の核としています。「持続可能」と「循環型」をキーワードに、食の安全と農地環境の保全を通じて、豊かな農業の未来を次世代へつなぎます。',
					'Organic Pure Brown uses sugarcane residue from sugar production as its raw material. Spent fertilizer returns to the soil to grow sugarcane once more — this resource cycle is the core of our business. With "sustainable" and "cyclical" as our keywords, we work to safeguard food safety and farmland, carrying a richer agricultural future to the next generation.'
				) ); ?>
			</p>
		</div>
	</div>
</section>

<?php lp_cta(); ?>
<?php lp_footer(); ?>
