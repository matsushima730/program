<?php
/**
 * Template Name: 会社案内（再生計画）
 *
 * @package SaiseiKeikaku_LP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/lp-shared.php';
$cfg = lp_cfg();

lp_head(
	lp_t( '会社案内', 'About the Company' ),
	lp_t(
		'有限会社再生計画の会社案内。「持続可能」と「循環型」をキーワードに、植物活性液・有機肥料の開発・販売を行う農業資材メーカーです。',
		'About Saisei Keikaku Co., Ltd. — an agricultural-input maker developing and selling plant activator and organic fertilizer under the keywords "sustainable" and "cyclical".'
	)
);
lp_header( 'company' );
lp_pagehead( 'COMPANY', lp_t( '会社案内', 'About the Company' ) );
?>

<section class="lp-section">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">MESSAGE</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '代表挨拶', 'Message from the CEO' ) ); ?></h2>
		</div>

		<div class="lp-prose" style="margin-top:34px;">
			<?php if ( 'en' === lp_lang() ) : ?>
				<p>In recent years, we have faced many environmental challenges — climate change, waste management, the decline of nearby nature. These are problems we must solve.</p>
				<p>Saisei Keikaku Co., Ltd. works to build a business model in harmony with the global environment, guided by the keywords "sustainable" and "cyclical". Without being bound by conventional methods, we continue to challenge ourselves with new solutions and innovation.</p>
				<p>While responding to our customers' needs, we will continue to propose a business model rooted in local production for local consumption — one that carries forward to the next generation.</p>
				<p style="text-align:right;font-weight:700;color:var(--green-dark);">Saisei Keikaku Co., Ltd. &nbsp; CEO &nbsp; <?php echo esc_html( lp_cf( 'ceo' ) ); ?></p>
			<?php else : ?>
				<p>近年、地球温暖化や廃棄物問題、身近な自然の減少など、私たちは多くの環境問題を解決していかなくてはなりません。</p>
				<p>有限会社再生計画は、「持続可能」と「循環型」をキーワードに、地球環境と調和したビジネスモデルづくりに取り組んでいます。従来の手法にとらわれることなく、新しい解決策の開拓と革新に挑戦し続けます。</p>
				<p>お客様のニーズにお応えしながら、次世代へと続く地産地消につながるビジネスモデルをご提案してまいります。</p>
				<p style="text-align:right;font-weight:700;color:var(--green-dark);">有限会社再生計画　代表取締役　<?php echo esc_html( lp_cf( 'ceo' ) ); ?></p>
			<?php endif; ?>
		</div>

		<div class="lp-quote">
			<p><?php echo esc_html( lp_t(
				'「持続可能」と「循環型」がキーワード。独自の効果を持った製品を取り扱っています。利用に特別な技能や注意を必要とせず、誰でも簡単に利用できることをモットーとしています。',
				'"Sustainable" and "cyclical" are our keywords. We handle products with distinctive effectiveness — designed so that anyone can use them, no special skills or precautions required.'
			) ); ?></p>
		</div>

		<div class="lp-company">
			<table>
				<tbody>
					<tr><th><?php echo esc_html( lp_t( '会社名', 'Company name' ) ); ?></th><td><?php echo esc_html( lp_company_name() ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '代表者', 'Representative' ) ); ?></th><td><?php echo esc_html( lp_t( '代表取締役　', 'CEO &nbsp; ' ) ); ?><?php echo esc_html( lp_cf( 'ceo' ) ); ?></td></tr>
					<?php if ( ! empty( $cfg['capital'] ) ) : ?>
					<tr><th><?php echo esc_html( lp_t( '資本金', 'Capital' ) ); ?></th><td><?php echo esc_html( lp_cf( 'capital' ) ); ?></td></tr>
					<?php endif; ?>
					<tr><th><?php echo esc_html( lp_t( '所在地', 'Address' ) ); ?></th><td><?php echo esc_html( lp_cf( 'address' ) ); ?></td></tr>
					<?php if ( $cfg['tel'] ) : ?>
					<tr><th><?php echo esc_html( lp_t( '電話番号', 'Tel' ) ); ?></th><td><?php if ( $cfg['tel_link'] ) : ?><a href="tel:<?php echo esc_attr( $cfg['tel_link'] ); ?>"><?php endif; ?><?php echo esc_html( $cfg['tel'] ); ?><?php if ( $cfg['tel_link'] ) : ?></a><?php endif; ?></td></tr>
					<?php endif; ?>
					<?php if ( $cfg['fax'] ) : ?>
					<tr><th>FAX</th><td><?php echo esc_html( $cfg['fax'] ); ?></td></tr>
					<?php endif; ?>
					<tr><th><?php echo esc_html( lp_t( 'メールアドレス', 'Email' ) ); ?></th><td><a href="mailto:<?php echo esc_attr( $cfg['mail'] ); ?>"><?php echo esc_html( $cfg['mail'] ); ?></a></td></tr>
					<tr><th><?php echo esc_html( lp_t( '事業内容', 'Business' ) ); ?></th><td><?php echo esc_html( lp_t( '植物活性液ピュアグリンの開発・販売／植物性有機肥料オーガニックピュアブラウンの製造・販売', 'Development and sales of Pure Green plant activator / Manufacture and sales of Organic Pure Brown plant-based fertilizer' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '主要製品', 'Core products' ) ); ?></th><td><?php echo esc_html( lp_t( '植物活性液「ピュアグリン（Pure Green）」／植物性有機肥料「オーガニックピュアブラウン」', 'Pure Green plant activator / Organic Pure Brown plant-based fertilizer' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '経営理念', 'Philosophy' ) ); ?></th><td><?php echo esc_html( lp_t( '「持続可能」と「循環型」 ― 長期利用と再利用をモットーに環境に配慮した農業資材を提供する', '"Sustainable" and "cyclical" — providing eco-conscious farm inputs built around long-term use and reuse.' ) ); ?></td></tr>
					<tr><th><?php echo esc_html( lp_t( '取り組み', 'Initiatives' ) ); ?></th><td><?php echo esc_html( lp_t( 'SDGsへの取り組み', 'SDGs commitments' ) ); ?></td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<section class="lp-section lp-section--soft">
	<div class="lp-wrap">
		<div class="lp-center">
			<span class="lp-eyebrow">ACCESS</span>
			<h2 class="lp-h2"><?php echo esc_html( lp_t( '所在地・アクセス', 'Address & Access' ) ); ?></h2>
			<?php if ( $cfg['address'] ) : ?>
			<p class="lp-lead"><?php echo esc_html( lp_cf( 'address' ) ); ?></p>
			<?php endif; ?>
		</div>
		<div class="lp-company" style="margin-top:24px;">
			<table>
				<tbody>
					<tr><th><?php echo esc_html( lp_t( '住所', 'Address' ) ); ?></th><td><?php echo esc_html( lp_cf( 'address' ) ); ?></td></tr>
					<?php if ( $cfg['tel'] ) : ?>
					<tr><th>TEL<?php if ( $cfg['fax'] ) { echo ' / FAX'; } ?></th><td>TEL：<?php echo esc_html( $cfg['tel'] ); ?><?php if ( $cfg['fax'] ) { echo '　/　FAX：' . esc_html( $cfg['fax'] ); } ?></td></tr>
					<?php endif; ?>
					<tr><th><?php echo esc_html( lp_t( 'メール', 'Email' ) ); ?></th><td><a href="mailto:<?php echo esc_attr( $cfg['mail'] ); ?>"><?php echo esc_html( $cfg['mail'] ); ?></a></td></tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<?php lp_cta(); ?>
<?php lp_footer(); ?>
