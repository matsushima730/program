【SDGs 公式素材の配置について】

SDGsのロゴおよび各目標のアイコンは国際連合の公式素材です。
著作・商標の関係から、必ず下記の公式サイトからダウンロードした
正規ファイルを配置してください。

■ ダウンロード元（国際連合 公式）
  https://www.un.org/sustainabledevelopment/news/communications-material/
  ※ 日本語版・英語版の両方をダウンロードしてください。

■ 配置先フォルダとファイル名
  表示言語に応じて自動で切り替わります。下記のとおり
  「ja（日本語）」「en（英語）」のフォルダを作成し、配置してください。

  images/sdgs/ja/      ← 日本語表記の素材
      sdgs-logo.png … SDGsロゴ（日本語：持続可能な開発目標）
      sdg-03.png    … 目標3
      sdg-06.png    … 目標6
      sdg-09.png    … 目標9
      sdg-12.png    … 目標12
      sdg-15.png    … 目標15

  images/sdgs/en/      ← 英語表記の素材
      sdgs-logo.png … SDGsロゴ（英語：SUSTAINABLE DEVELOPMENT GOALS）
      sdg-03.png    … GOAL 3
      sdg-06.png    … GOAL 6
      sdg-09.png    … GOAL 9
      sdg-12.png    … GOAL 12
      sdg-15.png    … GOAL 15

■ 動作について
  ・サイトを日本語表示にすると ja フォルダ、英語表示にすると en フォルダの
    画像が自動的に使用されます。
  ・ファイルを配置するまでは、各目標の公式カラーのプレースホルダが表示されます。

------------------------------------------------------------
【ISO14001 認証ロゴについて】（images/ フォルダ）

ISO14001の認証ロゴ画像（Intertek / UKAS）は、
  images/iso14001-logo.png
というファイル名で images フォルダに配置してください。
配置すると、ISO14001ページに自動的に表示されます。
